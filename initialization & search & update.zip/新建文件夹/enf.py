import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
import glob
import lmdb
import os
import time
import matplotlib.pyplot as plt
import caffe
from PIL import Image
from caffe.proto import caffe_pb2
import shutil


def decryption1(key, start=500, x0=0.1):
    for _ in range(start):
        x = key * x0 * (1 - x0)
        x0 = x
    return x, x0


def decryption2(imgpath,x,x0,count):
    img = Image.open(imgpath)
    #	img = img_en
    img_de = Image.new(mode=img.mode, size=img.size)
    width, height = img.size
    chaos_seq = np.zeros(width * height)
    for i in range(width * height):
        x = key * x0 * (1 - x0)
        x0 = x
        chaos_seq[i] = x
    idxs_de = np.argsort(chaos_seq)
    i, j = 0, 0
    for idx in idxs_de:
        col = int(idx % width)
        row = int(idx // width)
        img_de.putpixel((col, row), img.getpixel((i, j)))
        i += 1
        if i >= width:
            j += 1
            i = 0
    img_de.save('G:/answer/' + str(count) + '.jpg')


# return idxs_de

# return idxs_de


def Distance(arr1, arr2):
    distance = 0
    for i in range(0, len(arr1)):
        if arr1[i] != arr2[i]:
            distance = distance + 1
    return distance


def Distance2(EncRv1, EncRv2):
    return np.int(np.round((128 - (np.dot(EncRv1.T, EncRv2))) / 2))


def walk(path, nodeList):
    for root, dirs, files in os.walk(path):
        for dir in dirs:
            nodeList.append(os.path.join(root, dir) + '\\')


def generate():
    configFile = open('config.txt', 'r')
    config = configFile.read()
    configFile.close()
    pictureList = glob.glob(config.split('\n')[4] + "*/*.jpg")
    outputFile1 = open('F:/file_list.txt', 'w')
    for pic in pictureList:
        outputFile1.write(pic + ' 0\n')
    outputFile1.close()
    shutil.rmtree('F:/temp')
    num = str(int(config.split('\n')[1]) * 25)
    command = 'F:/caffe-windows/scripts/build/tools/Release/extract_features.exe F:/caffe-windows/examples/myExample_iter_431534.caffemodel F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt fc7 F:/temp ' + num + ' lmdb GPU 0'
    os.system(command)
    lmdb_env = lmdb.open('F:/temp', readonly=True)
    lmdb_txn = lmdb_env.begin()
    lmdb_cursor = lmdb_txn.cursor()
    datum = caffe_pb2.Datum()
    imgeCnt = 0
    f2 = open('feature.csv', 'w')
    for key, value in lmdb_cursor:
        datum.ParseFromString(value)
        label = datum.label
        data = caffe.io.datum_to_array(datum)
        DIM = datum.channels
        imgeCnt = imgeCnt + 1
        if (imgeCnt % 100 == 0):
            print("imgeCnt=" + str(imgeCnt))
        for i in range(DIM - 1):
            f2.write(str(data[i][0][0]) + ", ")
        f2.write(str(data[DIM - 1][0][0]) + "\n")

    lmdb_env.close()
    f2.close()
    print (imgeCnt)


configFile = open('config.txt', 'r')
config = configFile.read()
configFile.close()
nbits = int(config.split('\n')[0])
key = np.float(config.split('\n')[7])
x,x0 = decryption1(key)

generate()

nCount = 0
tCount = 0
allPic = []
for dir in os.listdir(config.split('\n')[4]):
    for pic in os.listdir(config.split('\n')[4] + dir + '/'):
        allPic.append(config.split('\n')[4] + dir + '/' + pic)

sampleMean = np.loadtxt('mean.csv', float, delimiter=',')

a = np.loadtxt('feature.csv', float, delimiter=',')
pc = np.loadtxt('Wx.csv', float, delimiter=',')
R = np.loadtxt('R.csv', float, delimiter=',')
sampleMean = np.loadtxt('mean.csv', float, delimiter=',')
print np.shape(sampleMean)
print np.shape(a)
a = a - sampleMean
a = np.dot(a, pc)
a = np.dot(a, R)
a[a >= 0] = 1
a[a < 0] = 0
# print np.shape(a)
count = 0
for Q_Path in allPic:
    # count = 0
    # time_start = time.time()
    Q = [a[count]]
    S = np.loadtxt(config.split('\n')[5] + 'S.txt', int)
    M1 = np.loadtxt(config.split('\n')[5] + 'M1.txt', int)
    M2 = np.loadtxt(config.split('\n')[5] + 'M2.txt', int)
    RvArr2 = Q[0]
    # RvArr2 = Q[0] - sampleMean
    RvArr21 = np.zeros(nbits).astype(int)
    RvArr22 = np.zeros(nbits).astype(int)
    for i in range(0, nbits):
        if S[i] == 0:
            RvArr21[i] = RvArr2[i]
            RvArr22[i] = RvArr2[i]
        else:
            if RvArr2[i] == 1:
                num1 = np.random.randint(100)
                num2 = num1 * (-1) + 1
                if (np.random.randint(2) == 0):
                    RvArr21[i] = num1
                    RvArr22[i] = num2
                else:
                    RvArr21[i] = num2
                    RvArr22[i] = num1
            elif RvArr2[i] == -1:
                num1 = np.random.randint(100)
                num2 = num1 * (-1) - 1
                if (np.random.randint(2) == 0):
                    RvArr21[i] = num1
                    RvArr22[i] = num2
                else:
                    RvArr21[i] = num2
                    RvArr22[i] = num1

    EncRv2 = np.hstack((np.dot(np.linalg.inv(M1), RvArr21), np.dot(np.linalg.inv(M2), RvArr22)))
    # print EncRv2
    # time_end = time.time()
    # print('Time cost = %fs' % (time_end - time_start))
    # print '################'

    ##############################################################3

    root = ''

    path = config.split('\n')[6]
    files = os.listdir(path)
    for file in files:
        if os.path.isdir(path + file):
            root = path + file + '\\'
            break

    # print root
    # t = root.split('/')
    # print len(t)
    # print t[len(t)-2]

    nodeList = []
    # nodeList_ = []
    NolList = []
    disList = []
    sumList = []
    tagList = []

    walk(root, nodeList)
    # time_start2 = time.time()
    for name in nodeList:
        #level = len(name.split('\\')) - 5
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
        while level + 1 > len(disList):
            disList.append([])
            # sumList.append(0)
            sumList.append(0)
            tagList.append(0)
            # nodeList_.append([])
    MinDis = 9999
    MinName = ''
	#MinName = []
    for name in nodeList:
        # level = len(name.split('\\')) - 5
        # while level + 1 > len(disList):
        #     disList.append([])
        #     # sumList.append(0)
        #     sumList.append(0)
        #     tagList.append(0)
        #     nodeList_.append([])
        # print name.split('\\')[len(name.split('\\'))-2].split(',')[0]
        #print name
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
        #print level
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        arr = file.read().split('\n')[0]
        file.close()
        arr = np.array(arr.split(','))
        # arr = map(''.join, zip(*[iter(arr)] * 1))
        arr = np.array(map(int, arr))
        dis = Distance2(arr, EncRv2)
        #if dis < MinDis and level == 0:
        #    MinName = []
        #    MinDis = dis
        #elif dis==MinDis and level == 0:
		#    MinName.append(name)
        if dis < MinDis and level ==0:
            MinName = name
            MinDis = dis
        disList[level].append(dis)

    # print disList

    for i in range(0, len(disList)):
        xList = argsort(disList[i])
        if len(disList[i]) <= 3:
            tagList[i] = disList[i][xList[len(disList[i]) - 1]]
        else:
            tagList[i] = disList[i][xList[2]]
        for num in disList[i]:
            # sumList[i] = sumList[i] + num - min(disList[i])
            sumList[i] = sumList[i] + num
        tagList[i] = 1 - (tagList[i] * 1.0 / sumList[i])
    # print sumList
    # print disList
    # print tagList
    # print sumList
    # print disList

    # print numList
    # print sumList

    for name in nodeList:
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        # level = len(name.split('\\')) - 5
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])

        # nodeList_[level].append(name)
        arr = file.read().split('\n')[0]
        file.close()
        arr = np.array(arr.split(','))
        arr = np.array(map(int, arr))
        # NolList.append(1 - ((Distance2(arr, EncRv2) - min(disList[level])) * 1.0 / sumList[level]))

        if (len(disList[level]) == 1):
            NolList.append(1)
        else:
            NolList.append(1 - (Distance2(arr, EncRv2) * 1.0 / sumList[level]))
        # print NolList
        # print name
        # print Distance(Q[0],arr)


    # raw_input()

    def judge(leafList):
        for name in leafList:
            if name.split('\\')[len(name.split('\\')) - 2].split(',')[0] != '0':
                return False

        return True


    # nodeList = nodeList_
    # for i in range(0,len(nodeList)):
    #     print nodeList[i]
    #     print NolList[i]
    # print disList
    leafList = [root]
    while (not judge(leafList)):
        for path in leafList:
            if path.split('\\')[len(path.split('\\')) - 2].split(',')[0] != '0':
                new = os.listdir(path)
                for i in range(0, len(new)):
                    if '.txt' in new[i]:
                        new.remove(new[i])
                        break
                for i in range(0, len(new)):
                    new[i] = path + new[i] + '\\'
                for name in new:
                    # level = len(name.split('\\')) - 5
                    level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
                    pos = nodeList.index(name)
                    if NolList[pos] >= tagList[level]:
                    #if NolList[pos] >= 0.96:
                        # if NolList[pos] >= 0.96:
                        leafList.append(name)
                        # print leafList
                leafList.remove(path)

    # for name in leafList:
    #     print name
    picList = []
    disList = []

    # for i in range(0,len(disList)):
    #     for

    #for i in range(0,len(MinName)):
        #if not (MinName[i] in leafList) and MinName[i] != '':
            #leafList.append(MinName[i])
    if not (MinName in leafList) and MinName != '':
        leafList.append(MinName)
	print MinName

    for path in leafList:
        temp = os.listdir(path)
        temp.remove(path.split('\\')[len(path.split('\\')) - 2] + '.txt')
        for i in range(0, len(temp)):
            temp[i] = path + temp[i]
        picList = picList + temp

    # count1 = 0

    for path in leafList:
        file = open(config.split('\n')[6] + path.split('\\')[len(path.split('\\')) - 2] + 'record.txt', 'r')
        strList = file.read().split('\n')
        for str in strList:
            if str != '':
                # print str
                # count1 = count1 + 1
                str = np.array(str.split(','))
                str = np.array(map(int, str))
                disList.append(Distance2(str, EncRv2))

    # print count1

    argList = np.argsort(disList)
    # time_end2 = time.time()
    # print('Time cost = %fs' % (time_end2 - time_start2))
    print Q_Path
    if (len(argList) > 5):
        for i in range(0, 1):
            #decryption2(picList[argList[i]],x,x0,count)
            name = picList[argList[i]].split('\\')[len(picList[argList[i]].split('\\')) - 1]
            print name
            if name.split('_')[0] != Q_Path.split('/')[3].split('_')[0]:
                nCount = nCount + 1
            else:
                tCount = tCount + 1
    print nCount
    print tCount
    print tCount * 1.0 / (nCount + tCount)
    # count = count + 1
    count = count + 1
    # raw_input()

    # print Q_Path
    # Q_Path = 'G:/008_0001.jpg'
    # image = caffe.io.load_image(Q_Path)
    # transformed_image = transformer.preprocess('data', image)
    # net.blobs['data'].data[...] = transformed_image
    # output = net.forward()
    # feature = net.blobs['fc7'].data[0]
    # feature_standarlized = (feature - min(feature)) / (max(feature) - min(feature))
    # tmpf = feature_standarlized.reshape(1, feature_standarlized.size)
    # s = tmpf.tolist()
    # fe = reduce(lambda x, y: x + y, s)
    # fe = mat(fe)
    # pc = np.loadtxt('pc.txt', float)
    # R = np.loadtxt('r.txt', float)
    # temp = np.array(np.dot(np.dot(fe,pc),R))
    # fe = fe - sampleMean
    # fe = np.array(np.dot(fe, pc))
    # temp = np.array(np.dot(fe, R))
    # temp[temp < 0] = 0
    # temp[temp > 0] = 1
    # Q = np.real(temp).astype(int)
    # print Q
    # break
