import numpy  as np
import matplotlib.pyplot as plt
import matplotlib.image as ima
import os
import pickle
import sys
import caffe


model_root='G:/caffe/models/'
model_file = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
pretrained = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
npload = 'G:/caffe/python/caffe/imagenet/ilsvrc_2012_mean.npy'

net = caffe.Net(model_file,pretrained,caffe.TEST)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_mean('data', np.load(npload).mean(1).mean(1))
transformer.set_raw_scale('data', 255)
transformer.set_channel_swap('data', (2,1,0))

image_file = 'G:/test2/001.ak47/001_0051.jpg'

im = caffe.io.load_image(image_file)
net.blobs['data'].reshape(1,3,227,227)
net.blobs['data'].data[...] = transformer.preprocess('data',im)
output = net.forward()
feature = net.blobs['fc6'].data[0]
print feature