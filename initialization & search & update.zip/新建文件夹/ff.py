import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
import glob
import os
import matplotlib.pyplot as plt
import caffe

def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance
    distance=0
    distance = np.dot(np.transpose(arr1),arr2)
    return distance
    # arr1 = np.array(arr1)
    # arr2 = np.array(arr2)
    # distance1 = (128 - (np.dot(arr1,arr2.T))) / 2
    # return distance1

def walk(path,nodeList):
    for root,dirs,files in os.walk(path):
        for dir in dirs:
            nodeList.append(os.path.join(root,dir) + '\\')


# plt.rcParams['figure.figsize']=(12,12)
# plt.rcParams['figure.dpi']=150
# plt.rcParams['image.interpolation']='nearest'
caffe.set_mode_gpu()
model_def = 'F:/caffe-windows/models/bvlc_reference_caffenet/deploy.prototxt'
model_weights = 'F:/caffe-windows/examples/bvlc_reference_caffenet.caffemodel'


net = caffe.Net(model_def,
                model_weights,
                caffe.TEST)
net.blobs['data'].reshape(50,3,227,227)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))
Q_Path = 'G:/train/001.ak47/001_0002.jpg'
image = caffe.io.load_image(Q_Path)
transformed_image=transformer.preprocess('data',image)
net.blobs['data'].data[...] = transformed_image
output = net.forward()
feature = net.blobs['fc7'].data[0]
feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
s=tmpf.tolist()
fe=reduce(lambda x,y:x+y,s)
fe = mat(fe)
sampleMean = np.loadtxt('mean.csv',float,delimiter=',')
pc = np.loadtxt('pc.txt',float)
R = np.loadtxt('r.txt',float)
#temp = np.array(np.dot(np.dot(fe,pc),R))
#fe = fe - (sampleMean*2500+fe)/2501
fe = fe-sampleMean
fe = np.array(np.dot(fe,pc))
temp = np.array(np.dot(fe,R))
temp[temp>=0] = 1
temp[temp<0] = 0
Q = np.real(temp).astype(int)
#print Q

for layer_name,blob in net.blobs.iteritems():
    print layer_name + '\t' + str(blob.data.shape)


root = ''

path = 'G:\\pictures\\'
files = os.listdir(path)
for file in files:
    if os.path.isdir(path + file):
        root  = path + file + '\\'
        break

# print root
# t = root.split('/')
# print len(t)
# print t[len(t)-2]

nodeList = []
nodeList_ = []
NolList = []
disList = []
sumList = []


walk(root,nodeList)

for name in nodeList:
    level = len(name.split('\\'))-5
    while level+1 > len(disList):
        disList.append([])
        sumList.append(0)
        nodeList_.append([])
    file = open(name+name.split('\\')[len(name.split('\\'))-2]+'.txt','r')
    arr = file.read().split('\n')[0]
    file.close()
    arr = map(''.join, zip(*[iter(arr)] * 1))
    arr = map(int, arr)
    dis = Distance(Q[0],arr)
    disList[level].append(dis)

for i in range(0,len(disList)):
    for num in disList[i]:
        #sumList[i] = sumList[i] + num - min(disList[i])
        sumList[i] = sumList[i] + num
    #print disList[i]


#print numList
#print sumList

for name in nodeList:
    file = open(name+name.split('\\')[len(name.split('\\'))-2]+'.txt','r')
    level = len(name.split('\\')) - 5
    nodeList_[level].append(name)
    arr = file.read().split('\n')[0]
    file.close()
    arr = map(''.join, zip(*[iter(arr)] * 1))
    arr = map(int, arr)
    #NolList.append(1- ((Distance(Q[0],arr) - min(disList[level])) * 1.0/sumList[level]))
    NolList.append(1- ((Distance(Q[0],arr)) * 1.0/sumList[level]))
    #print name
    #print Distance(Q[0],arr)

print NolList

def judge(leafList):
    for name in leafList:
        if name.split('\\')[len(name.split('\\'))-2].split(',')[0]!='0':
            return False

    return True


#nodeList = nodeList_

leafList = [root]

while(not judge(leafList)):
    for path in leafList:
        if path.split('\\')[len(path.split('\\'))-2].split(',')[0]!='0':
            new = os.listdir(path)
            l = 0
            for i in range(0,len(new)):
                if '.txt' in new[i]:
                    l = i
            new.remove(new[l])
            #print new
            for i in range(0,len(new)):
                new[i] = path + new[i] + '\\'
            for name in new:
                pos = nodeList.index(name)
                if NolList[pos] >=0.6:
                    leafList.append(name)
            leafList.remove(path)

#print leafList
picList = []
disList = []
for path in leafList:
    temp =  os.listdir(path)
    #print path.split('\\')[len(path.split('\\'))-2]+'.txt'
    temp.remove(path.split('\\')[len(path.split('\\'))-2]+'.txt')
    for i in range(0,len(temp)):
        temp[i] = path+temp[i]
    picList = picList + temp



for path in leafList:
    file = open('G:\\pictures\\' + path.split('\\')[len(path.split('\\'))-2] + 'record.txt','r')
    strList = file.read().split('\n')
    for Str in strList:
        if Str!='':
            Str = map(''.join, zip(*[iter(Str)] * 1))
            Str = map(int, Str)
            #print Distance(Q[0], Str)
            disList.append(Distance(Q[0],Str))
            #print Distance(Q[0],Str)

argList = np.argsort(disList)
#print argList[0]
if(len(argList)>5):
    for i in range(0,5):
        print picList[argList[i]]
        print disList[argList[i]]
else:
    for i in range(0,len(argList)):
        print picList[argList[i]]

zz = np.array(Q[0])
zz = zz.astype(str)
zz = np.array(zz.tolist())
zz = zz.tostring()
print zz
