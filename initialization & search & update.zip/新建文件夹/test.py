class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

class Solution:
    def PrintFromTopToBottom(self, root):
        L = [root]
        valList = []
        while(len(L)!=0):
            L_= []
            for node in L:
                valList.append(node.val)
            for node in L:
                if node.left!=None:
                    L_.append(node.left)
                if node.right!=None:
                    L_.append(node.right)
            L = L_


        return valList



root = TreeNode(10)
root.left = TreeNode(6)
root.right = TreeNode(14)
root.left.left = TreeNode(4)
root.left.right = TreeNode(8)
root.right.left = TreeNode(12)
root.right.right = TreeNode(16)
a = Solution()
print a.PrintFromTopToBottom(root)