import os
import shutil
import random
import glob
#
tt = 'G:/test2/'

pictureList = glob.glob(tt+"*/*.jpg")
outputFile1 = open('F:/file_list.txt', 'w')
count = 0
for pic in pictureList:
    outputFile1.write(pic + ' 0\n')
    count = count + 1
outputFile1.close()
print count

# file = open('F:/caffe-windows/examples/myExample/test.txt','r')
# l = file.read().split('\n')
# file2 = open('F:/caffe-windows/examples/myExample/test2.txt','w')
# for str in l:
#     str = 'F:/caffe-windows/examples/myExample/test/'+str
#     file2.write(str + '\n')
# file2.close()
# file.close()
#
# for dir in os.listdir('G:/test2'):
#     picList = os.listdir('G:/test2/'+dir)
#     if (len(picList)>=26):
#         no = random.sample(range(0,len(picList)),len(picList)-25)
#         for a in no:
#             os.remove('G:/test2/'+ dir + '/' + picList[a])


file = open('F:/record.txt','r')
Str = file.read()
file.close()
for dir in os.listdir('G:/new/256_ObjectCategories2'):
    picList = os.listdir('G:/new/256_ObjectCategories2/'+dir)
    # no = random.sample(range(0,len(picList_)),20)
    # for i in range(0,10):
    #     picList.append(picList_[no[i]])
    count = len(picList)
    if count<25:
        print dir +'  ' + str(count)
    for pic in picList:
        if(pic in Str ):#and count>=26):
            count = count -1
            os.remove('G:/new/256_ObjectCategories2/'+ dir + '/' + pic)
#
# file = open('F:/record.txt','r')
# Str = file.read()
# file.close()
# count = 0
# zz = 0
#
#
#
# bigList_ = os.listdir('G:/new/256_ObjectCategories2/')
# no_ = random.sample(range(0,len(bigList_)),50)
# bigList = []
# for i in range(0,50):
#     bigList.append(bigList_[no_[i]])
#     print bigList_[no_[i]]
#
# for dir in bigList:
#     picList_= os.listdir('G:/new/256_ObjectCategories2/'+dir)
#     no = random.sample(range(0,len(picList_)),25)
#     picList = []
#     for i in range(0,25):
#         picList.append(picList_[no[i]])
#     for pic in picList:
#         if pic in Str:
#             count = count + 1
#
# print 1 - (count * 1.0 / 1250)
#
# print zz
#for dir in bigList:

#print 1 - (count *1.0 / 5060)
#for i in range(0,253):
#    os.mkdir('G:/pictures/'+'0,'+str(i))

# count = 0
# for name in os.listdir('G:/256_ObjectCategories2/'):
#     count = 0
#     for name2 in os.listdir('G:/256_ObjectCategories2/'+ name):
#         if(count<50):
#             os.remove('G:/256_ObjectCategories2/'+ name + '/' + name2)
#         count = count + 1


#
# outputFile1 = open('F:/caffe-windows/examples/myExample/train.txt','r')
# outputFile2 = open('F:/caffe-windows/examples/myExample/test.txt','r')
#
#
# # for pic in os.listdir('F:/caffe-windows/examples/myExample/train'):
# #     if int(pic.split('_')[0])!=256:
# #         outputFile1.write(pic + ' ' + str(int(pic.split('_')[0])-1) + '\n')
# #     else:
# #         outputFile1.write(pic + ' ' + str(255) + '\n')
# # outputFile1.close()
# #
# # for pic in os.listdir('F:/caffe-windows/examples/myExample/test'):
# #     if int(pic.split('_')[0])!=256:
# #         outputFile2.write(pic + ' ' + str(int(pic.split('_')[0])-1) + '\n')
# #     else:
# #         outputFile2.write(pic + ' ' + str(255) + '\n')
# # outputFile2.close()
#
#
#
# list1 = outputFile1.read().split('\n')
# outputFile1.close()
# no = random.sample(range(0, len(list1)), len(list1))
# print len(no)
# outputFile1 = open('F:/caffe-windows/examples/myExample/train2.txt','w')
# for i in range(0,len(no)):
#     outputFile1.write(list1[no[i]]+'\n')
# outputFile1.close()
#
# list2 = outputFile2.read().split('\n')
# outputFile2.close()
# no2 = random.sample(range(0,len(list2)),len(list2))
# print len(no2)
# outputFile2 = open('F:/caffe-windows/examples/myExample/test2.txt','w')
# for i in range(0,len(no2)):
#     outputFile2.write(list2[no2[i]] + '\n')
# outputFile2.close()


# Source = 'G:/256_ObjectCategories/'
#
# tag = 0
# for name in os.listdir(Source):
#     path = Source + name +'/'
#     picList = os.listdir(path)
#     NoList = random.sample(range(0, len(picList)), len(picList)/11)
#     for i in range(0,len(picList)):
#         if('.jpg' in picList[i] and not i in NoList):
#             outputFile1.write( picList[i]+ ' '+str(tag)+'\n')
#             shutil.copy(path + picList[i], 'G:/caffe/examples/myExample/train')
#         elif('.jpg' in picList[i] and i in NoList):
#              outputFile2.write(picList[i]+' '+str(tag)+'\n')
#              shutil.copy(path + picList[i], 'G:/caffe/examples/myExample/test')
#
#     tag = tag+1
#     print tag
# outputFile1.close()
# outputFile2.close()
#
# outputFile1 = open('G:/caffe/examples/myExample/train.txt','w')
#
# for name in os.listdir('G:/caffe/examples/myExample/train'):
#     outputFile1.write(name + ' ' + str(int(name.split('_')[0])-1) + '\n')
#
# outputFile1.close()