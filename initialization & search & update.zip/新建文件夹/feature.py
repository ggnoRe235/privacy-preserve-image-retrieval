import numpy as np
from numpy import *
import lmdb
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
# try trainPCAH.m
import glob
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
import sys
import os
import caffe
import pickle
from sklearn.datasets import make_blobs
from sklearn.decomposition import PCA

# plt.rcParams['figure.figsize']=(12,12)
# plt.rcParams['figure.dpi']=150
# plt.rcParams['image.interpolation']='nearest'
# plt.rcParams['image.cmap']='jet'
# caffe.set_mode_gpu()
# model_def = 'F:/caffe-windows/models/bvlc_reference_caffenet/deploy.prototxt'
# model_weights = 'F:/caffe-windows/examples/bvlc_reference_caffenet.caffemodel'
# # #model_def = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.prototxt'
# # #model_weights = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel'
# net = caffe.Net(model_def,
#                 model_weights,
#                 caffe.TEST)
# transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
# transformer.set_transpose('data',(2,0,1))
# transformer.set_raw_scale('data',255)
# transformer.set_channel_swap('data',(2,1,0))
# transformer.set_mean('data',np.load('F:/caffe-windows/python/caffe/imagenet/ilsvrc_2012_mean.npy'))
# net.blobs['data'].reshape(50,3,227,227)
#
# #
# #
# # #pictureList = ['cat.jpg','cat2.jpg','fish-bike.jpg','cat gray.jpg','cat_gray.jpg']#,'fish-bike.jpg','cat gray.jpg','cat_gray.jpg'}
# #
# pictureList = glob.glob(r"G:/train2/*/*.jpg")
# # #pictureList = glob.glob(r"G:/caffe/examples/images/*.jpg")
# # #print pictureList
# # #print pictureList
# #
# featAll = []
# #
# for pic in pictureList:
#     print pic
#     #image = caffe.io.load_image('G:/caffe/examples/images/'+pic)
#     image = caffe.io.load_image(pic)
#     transformed_image=transformer.preprocess('data',image)
#     net.blobs['data'].data[...] = transformed_image
#     output = net.forward()
#     fe = net.blobs['fc7'].data[0]
#     #feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
#     #tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
#     #tmpf = feature.reshape(1, feature.size)
#     #print tmpf
#     #tmpf = feature.reshape(1,feature.size)
#     #s=tmpf.tolist()
#     #fe=reduce(lambda x,y:x+y,s)
#     #print fe
#     featAll.append(fe)
#
#     # load labels
#
#     imagenet_labels_filename = 'F:/caffe-windows/data/ilsvrc12/synset_words.txt'
#     labels = np.loadtxt(imagenet_labels_filename, str, delimiter='\t')
#     labels = np.loadtxt(imagenet_labels_filename, str, delimiter='\t')
#     # sort top k predictions from softmax output
#     top_k = net.blobs['prob'].data[0].flatten().argsort()[-1:-6:-1]
#     print labels[top_k]

#
# reg = 0.0001
#
#X = featAll
# Y = np.zeros((2500,50),float)
# count = 0
# for i in range(1,2501):
#     Y[i-1][count] = 1
#     if i % 50==0:
#         count = count + 1
#     if count == 50:
#         break
#
#
#np.savetxt('X.csv',X,delimiter=',')
# np.savetxt('Y.csv',Y,delimiter=',')
#
# X = np.loadtxt('X.csv',float,delimiter = ',')
# pc = np.loadtxt('Wx.csv',float,delimiter=',')
# np.savetxt('pc.txt',pc)
# sampleMean = np.loadtxt('mean.csv',float,delimiter=',')
# R = np.loadtxt('R.csv',float,delimiter=',')
# np.savetxt('r.txt',R)
# X = X - sampleMean

#
# a = np.loadtxt('feature.csv',int,delimiter=',')
# pc = np.loadtxt('Wx.csv',float,delimiter=',')
# R = np.loadtxt('R.csv',float,delimiter=',')
# sampleMean = np.loadtxt('mean.csv',float,delimiter=',')
# a = a-sampleMean
# a = np.dot(a,pc)
# a = np.dot(a,R)
# a[a>=0]=1
# a[a<0]=0
# 
a= np.loadtxt('B.csv',int,delimiter=',')
outputFile = open('outputFile1.txt','w')

for i in range(0,2500):
     tempArr = a[i]
     tempList = list(tempArr)
     tempList = map(int,tempList)
     tempList = map(str,tempList)
     #print tempList
     result = ''.join(tempList)
     #print result
     outputFile.write(result+"\n")
outputFile.close()



