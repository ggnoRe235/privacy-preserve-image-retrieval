from sklearn.cluster import KMeans
from sklearn.externals import joblib
from sklearn import cluster
import numpy as np
import shutil
import os
import pickle
#num of set
#k = 12
# n_clusters is the number of final clusters
n_clusters = 30
nbits = 128
Tht = 0.5

# each set has its own txt file to record the RV

# 128d data cluster

inputFile = open('E:/PyCharm/untitled/outputFile.txt','r')
inputData = inputFile.read()
inputFile.close()
list = inputData.split('\n')

num = np.shape(list)[0]

arr = map(''.join , zip(*[iter(list[0])]*1))
arr = map(int, arr)
#arr = np.array(arr)
#print np.shape(arr)


for i in range(1,num-1):
    #print i
    Str = list[i]
    #print Str
    tempList = map(''.join , zip(*[iter(Str)]*1))
    tempList = map(int, tempList)
    #tempList = np.array(tempList)
    #print tempList
    arr = np.vstack((arr,tempList))
    #print np.shape(arr)
    #print np.shape(arr)
    #print np.shape(arr)

#print arr0
#print np.shape(arr)


estimator = KMeans(n_clusters)

res = estimator.fit_predict(arr)
label_pred = estimator.labels_
centroids = estimator.cluster_centers_
inertia = estimator.inertia_


#print label_pred
#print np.shape(label_pred)
#print centroids
#print inertia

# Arrange all the pictures according to the label_pred matrix

CountOfFile = 0
CountOfDir = 0

SourceDir = 'G:/256_ObjectCategories/'
SourceDirEnd = ['001.ak47/','002.american-flag/','003.backpack/','004.baseball-bat/','005.baseball-glove/','006.basketball-hoop/','007.bat/','008.bathtub/','009.bear/','010.beer-mug/','011.billiards/','012.binoculars/','013.birdbath/','014.blimp/','015.bonsai-101/','016.boom-box/','017.bowling-ball/','018.bowling-pin/','019.boxing-glove/','020.brain-101/','021.breadmaker/','022.buddha-101/','023.bulldozer/','024.butterfly/','025.cactus/','026.cake/','027.calculator/','028.camel/','029.cannon/','030.canoe/']
TargetDir = 'G:/pictures/'

TargetDirEnd = []
RecordName = []
RvFile = []
for i in range(0,n_clusters):
    TargetDirEnd.append('0,'+str(i)+'/')
    RecordName.append('0,'+str(i)+'.txt')
    RvFile.append(open('G:/pictures/0,'+ str(i) + 'record.txt','a'))
    #RvFile.append(open(TargetDir+TargetDirEnd[i]+'record.txt','a'))
#TargetDirEnd = ['0/','1/','2/','3/','4/','5/','6/','7/','8/','9/','10/','11/','12/','13/','14/','15/','16/','17/','18/','19/','20/','21/','22/','23/','24/','25/','26/','27/','28/','29/','30/']
#RecordName = ['0.txt','1.txt','2.txt','3.txt','4.txt','5.txt','6.txt','7.txt','8.txt','9.txt','10.txt','11.txt','12.txt','13.txt','14.txt','15.txt','16.txt','17.txt','18.txt','19.txt','20.txt','21.txt','22.txt','23.txt','24.txt','25.txt','26.txt','27.txt','28.txt','29.txt','30.txt',]



#FileName = '0xx_0xxx'
FileName = ''
#shutil.copy(source_file,target_ir)
for number in label_pred:
    if CountOfFile == 60:
        CountOfFile = 0
        CountOfDir = CountOfDir + 1
    CountOfFile = CountOfFile + 1
    FileName = ''
    if CountOfFile <=9:
        if CountOfDir + 1 <=9:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_000' + str(CountOfFile) + '.jpg'
            #print FileName
        else:
            FileName = FileName +SourceDirEnd[CountOfDir].split('.')[0] + '_000' + str(CountOfFile) + '.jpg'
            #print FileName

    else:
        if CountOfDir + 1  <= 9:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_00' + str(CountOfFile) + '.jpg'
            #print FileName
        else:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_00' + str(CountOfFile) + '.jpg'
            #print FileName
    Source = SourceDir + SourceDirEnd[CountOfDir] + FileName
    Target = TargetDir + TargetDirEnd[number] + FileName
    shutil.copy(Source,Target)

new_RV = np.zeros((n_clusters,nbits))#,int)
cluster_num = np.zeros(n_clusters)
nSamples = np.shape(label_pred)[0]
for i in range(0,nSamples):
    new_RV[label_pred[i]] = new_RV[label_pred[i]] + arr[i]
    file = RvFile[label_pred[i]]
    tempstr = arr[i].astype(int)
    tempstr = tempstr.astype(str)
    file.write(np.array(tempstr.tolist()).tostring()+'\n')
    cluster_num[label_pred[i]] = cluster_num[label_pred[i]] + 1

for i in range(0,n_clusters):
    new_RV[i] = new_RV[i] / cluster_num[i]

for i in range(0,n_clusters):
    RvFile[i].close()
#print new_RV
#print cluster_num
new_RV[new_RV>=0.6] = 1
new_RV[new_RV<0.6] = 0
#new_RV = int(new_RV)
#new_RV = map(int,new_RV)
new_RV = new_RV.astype(int)
new_RV = new_RV.astype(str)
#print new_RV



for i in range(0,n_clusters):
    OutputFile = open(TargetDir+TargetDirEnd[i]+RecordName[i],'a')
    OutputFile.write(np.array(new_RV[i].tolist()).tostring()+'\n')
    # print new_RV[i]
    # print '############'
    # print new_RV[i].tostring()
    # print '############'
    OutputFile.write('0,'+str(i)+'|'+'\n') #E set
    OutputFile.write('0')#+'\n') #IND
    #OutputFile.write('0'+'\n')  #level
    #OutputFile.write(str(i))   # no
    OutputFile.close()
    OutputFile = open('G:/pictures/' + RecordName[i],'a')
    OutputFile.write(np.array(new_RV[i].tolist()).tostring())
    OutputFile.close()



# initialize finish, get C_set
C_Set = []
for i in range(0,n_clusters):
    C_Set.append(TargetDir+TargetDirEnd[i])

# while len(C_Set) > 1 do

#print C_Set
#print len(C_Set)

def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance


def FindNearest(C_Set):
    RecordMatrix = np.zeros((len(C_Set),len(C_Set)),int)

    minLevel = 9999
    for text in C_Set:
        if int(text.split('/')[2].split(',')[0]) < minLevel:
            minLevel = int(text.split('/')[2].split(',')[0])

    for i in range(0,len(C_Set)):
        file1 = open(C_Set[i]+C_Set[i].split('/')[2]+'.txt','r')
        #print C_Set[i]+C_Set[i].split('/')[2]+'.txt'
        str1 = file1.read().split('\n')[0]
        arr1 = map(''.join, zip(*[iter(str1)] * 1))
        arr1 = map(int, arr1)
        file1.close()
        for m in range(0,len(C_Set)):
            file2 = open(C_Set[m]+C_Set[m].split('/')[2]+'.txt','r')
            str2 = file2.read().split('\n')[0]
            arr2 = map(''.join, zip(*[iter(str2)] * 1))
            arr2 = map(int, arr2)
            file2.close()
            distance = Distance(arr1,arr2)
            RecordMatrix[i][m] = distance
            Cu = C_Set[i]
            Cv = C_Set[m]
            file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVu = content.split('\n')[0]
            RVu = map(''.join, zip(*[iter(RVu)] * 1))
            RVu = map(int, RVu)
            INDu = int(content.split('\n')[2])
            Esetu = len(content.split('\n')[1].split('|'))
            file.close()
            file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVv = content.split('\n')[0]
            RVv = map(''.join, zip(*[iter(RVv)] * 1))
            RVv = map(int, RVv)
            INDv = int(content.split('\n')[2])
            Esetv = len(content.split('\n')[1].split('|'))
            file.close()
            if C_Set[i].split('/')[2].split(',')[0] == C_Set[m].split('/')[2].split(',')[0] and C_Set[i].split('/')[2].split(',')[0]!='0':
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                if DM >= Tht:
                    RecordMatrix[i][m] = distance
                else:
                    RecordMatrix[i][m] = 9999999
            else:
                RecordMatrix[i][m] = distance

            if Esetu>=4:
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                levelu = int(C_Set[i].split('/')[2].split(',')[0])
                levelv = int(C_Set[m].split('/')[2].split(',')[0])
                if DM<Tht and levelu > levelv:
                    RecordMatrix[i][m] = 9999999
            if Esetv >= 4:
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                levelu = int(C_Set[i].split('/')[2].split(',')[0])
                levelv = int(C_Set[m].split('/')[2].split(',')[0])
                if DM < Tht and levelu < levelv:
                    RecordMatrix[i][m] = 9999999

                #RecordMatrix[i][m] = 9999999
    #print RecordMatrix


    #print RecordMatrix
    Min = 99999999
    x = 0
    y = 0
    for i in range(0,len(C_Set)):
        for m in range(0,len(C_Set)):
            if i!=m and RecordMatrix[i][m]<Min:
                x = i
                y = m
                Min = RecordMatrix[i][m]
            elif i!=m and RecordMatrix[i][m]==Min:
            #     #print C_Set[i]
            #     #print C_Set[m]
            #
                 level0 = int((C_Set[x].split('/')[2]).split(',')[0])
                 level1 = int((C_Set[y].split('/')[2]).split(',')[0])
                 level2 = int((C_Set[i].split('/')[2]).split(',')[0])
                 level3 = int((C_Set[m].split('/')[2]).split(',')[0])
                 max1 = max(level0,level1)
                 min1 = min(level0,level1)
                 max2 = max(level2,level3)
                 min2 = min(level2,level3)
                 if(max1 < max2):
                     x = i
                     y = m
            #     elif(max1 == max2 and min2 < min1):
            #         x = i
            #         y = m
    #print RecordMatrix
    return x,y




LevelCount = [n_clusters]

def merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,flag):
    #print 'here is me '
    if flag == True:
        newLevel = max(levelu,levelv) + 1
        dirName = ''
        if newLevel > len(LevelCount)-1:
            LevelCount.append(1)
            dirName = str(newLevel)+','+str(LevelCount[newLevel]-1)
        elif newLevel <=len(LevelCount)-1:
            LevelCount[newLevel] = LevelCount[newLevel]+1
            dirName = str(newLevel) + ',' + str(LevelCount[newLevel] - 1)

        newIND = Distance(RVu,RVv)
        newE_Set = ''

        for root, dirs, files in os.walk(Cu):
            for dir in dirs:
                if '0,' in dir and int(dir.split(',')[0])==0:
                    newE_Set = newE_Set + dir + '|'

        for root, dirs, files in os.walk(Cv):
            for dir in dirs:
                if '0,' in dir and int(dir.split(',')[0])==0:
                    newE_Set = newE_Set + dir + '|'

        if '0,' in Cu:
            newE_Set = newE_Set + Cu.split('/')[2] + '|'
        if '0,' in Cv:
            newE_Set = newE_Set + Cv.split('/')[2] + '|'


        #print newE_Set
        arr = np.zeros(nbits)
        count = 0
        for Str in newE_Set.split('|'):
            if Str!='':
                file = open('G:/pictures/' + Str + 'record.txt','r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    tempList = map(''.join, zip(*[iter(rv)] * 1))
                    tempList = map(int, tempList)
                    arr = arr + tempList
                    count = count + 1

        newE_Set = Cu.split('/')[2] + '|' + Cv.split('/')[2] + '|'

        arr = arr / count
        arr[arr >= 0.6] = 1
        arr[arr < 0.6] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        os.mkdir('G:/pictures/'+dirName)
        shutil.move(Cu,'G:/pictures/'+dirName)
        shutil.move(Cv,'G:/pictures/'+dirName)
        C_Set.append('G:/pictures/'+dirName+'/')
        C_Set.remove(Cu)
        C_Set.remove(Cv)

        OutputFile = open('G:/pictures/'+dirName+'/'+dirName+'.txt', 'a')
        OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
        OutputFile.write(newE_Set+'\n')
        OutputFile.write(str(newIND))
        OutputFile.close()
        #print newIND



    else:
        newE_Set = ''
        file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
        newE_Set = newE_Set + file.read().split('\n')[1]
        file.close()
        if levelu == levelv:
            file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
            newE_Set = newE_Set + file.read().split('\n')[1]
            file.close()
        elif levelu != levelv:
            newE_Set = newE_Set + Cv.split('/')[2] + '|'

        Set = ''
        for root, dirs, files in os.walk(Cu):
            for dir in dirs:
                if '0,' in dir and int(dir.split(',')[0])==0:
                    Set = Set + dir + '|'

        for root, dirs, files in os.walk(Cv):
            for dir in dirs:
                if '0,' in dir and int(dir.split(',')[0])==0:
                    Set = Set + dir + '|'

        if '0,' in Cu:
            Set = Set + Cu.split('/')[2] + '|'
        if '0,' in Cv:
            Set = Set + Cv.split('/')[2] + '|'

        print Set

        arr = np.zeros(nbits)
        count = 0
        for Str in Set.split('|'):
            if Str != '':
                file = open('G:/pictures/' + Str + 'record.txt', 'r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    tempList = map(''.join, zip(*[iter(rv)] * 1))
                    tempList = map(int, tempList)
                    arr = arr + tempList
                    count = count + 1

        arr = arr / count
        arr[arr >= 0.6] = 1
        arr[arr < 0.6] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        strList = []
        if levelu!=levelv:
            newIND = Distance(RVu,RVv)
        else:
            E_Setu = ''
            file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
            E_Setu = E_Setu + file.read().split('\n')[1]
            file.close()
            E_Setv = ''
            file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
            E_Setv = E_Setv + file.read().split('\n')[1]
            file.close()
            for name in E_Setu.split('|'):
                if name != '':
                    path = Cu + name + '/' + name +'.txt'
                    file = open(path,'r')
                    strList.append(file.read().split('\n')[0])
                    file.close()
            for name in E_Setv.split('|'):
                if name != '':
                    path = Cv + name + '/' + name +'.txt'
                    file = open(path,'r')
                    strList.append(file.read().split('\n')[0])
                    file.close()

            indList = []
            #print strList
            for str1 in strList:
                for str2 in strList:
                    #str1 = map(''.join, zip(*[iter(str1)] * 1))
                    #str1 = map(int, str1)
                    #str2 = map(''.join, zip(*[iter(str2)] * 1))
                    #str2 = map(int, str2)
                    indList.append(Distance(str1,str2))

            newIND = max(indList)

        if levelu > levelv:
            C_Set.remove(Cv)
            shutil.move(Cv,Cu)
        elif levelu == levelv:
            C_Set.remove(Cv)
            os.remove(Cv+Cv.split('/')[2]+'.txt')
            for files in os.listdir(Cv):
                shutil.move(Cv + files, Cu)
            os.rmdir(Cv)

        OutputFile = open(Cu + Cu.split('/')[2] + '.txt', 'w+')
        OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
        OutputFile.write(newE_Set + '\n')
        OutputFile.write(str(newIND))
        OutputFile.close()




    return C_Set


LevelCount = [n_clusters]


while len(C_Set)>1:
    # raw_input()
    #print C_Set
    if len(C_Set) > 2:
        x,y = FindNearest(C_Set)
    else:
        levelu = C_Set[0].split('/')[2].split(',')[0]
        levelv = C_Set[1].split('/')[2].split(',')[0]
        if levelu > levelv:
            x=0
            y=1
        elif levelu <levelv:
            x=1
            y=0
        elif levelu == levelv:
            if C_Set[0].split('/')[2].split(',')[1] > C_Set[0].split('/')[2].split(',')[1]:
                x=0
                y=1
            else:
                x=1
                y=0
    Cu = C_Set[x]
    Cv = C_Set[y]
    file = open(Cu+Cu.split('/')[2]+'.txt','r')
    content = file.read()
    RVu = content.split('\n')[0]
    RVu = map(''.join, zip(*[iter(RVu)] * 1))
    RVu = map(int, RVu)
    levelu = int((Cu.split('/')[2]).split(',')[0])
    INDu = int(content.split('\n')[2])
    file.close()
    file = open(Cv+Cv.split('/')[2]+'.txt','r')
    content = file.read()
    RVv = content.split('\n')[0]
    RVv = map(''.join, zip(*[iter(RVv)] * 1))
    RVv = map(int, RVv)
    levelv = int((Cv.split('/')[2]).split(',')[0])
    INDv = int(content.split('\n')[2])
    file.close()
    if INDu==0 and INDv==0:
        C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
        print Cu + ' + ' + Cv + ' ->new'
    else:
        max_value = max(INDu,INDv) * 1.0
        dis = Distance(RVu,RVv) * 1.0
        #print type(max_value)
        #print type(dis)
        DM = (abs(dis - max_value))/max_value
        #print type(DM)
        if DM >= Tht:
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
            print Cu + ' + ' + Cv + ' ->new'
        else:
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,False)
            print Cv + ' -> ' + Cu





