import numpy as np
import matplotlib.pyplot as plt
import scipy.io
plt.rcParams['figure.figsize']=(12,12)
plt.rcParams['figure.dpi']=150
plt.rcParams['image.interpolation']='nearest'
plt.rcParams['image.cmap']='jet'
import sys
import os
import caffe
caffe_root='G:/caffe/'
model_root='G:/caffe/models/'
caffe.set_mode_cpu()
model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
net = caffe.Net(model_def,
                model_weights,
                caffe.TEST)
net.blobs['data'].reshape(10,3,227,227)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))


pictureList = {'cat.jpg','fish-bike.jpg','cat gray.jpg','cat_gray.jpg'}
featAll = []

for pic in pictureList:
    image = caffe.io.load_image('G:/caffe/examples/cifar-10/train/0/'+pic)
    transformed_image=transformer.preprocess('data',image)
    net.blobs['data'].data[...] = transformed_image
    output = net.forward()
    feature = net.blobs['fc7'].data[0]
#print(feature.shape)
    feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
    tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
    s=tmpf.tolist()
    fe=reduce(lambda x,y:x+y,s)
#    print(fe)
#print len(fe)
#print type(fe)
#print(fe)
    featAll.append(fe)

#print featAll

# from sklearn.decomposition import PCA
#
def index_lst(lst, component=0, rate=0):
    # component: numbers of main factors
    # rate: rate of sum(main factors)/sum(all factors)
    # rate range suggest: (0.8,1)
    # if you choose rate parameter, return index = 0 or less than len(lst)
    if component and rate:
        print('Component and rate must choose only one!')
        sys.exit(0)
    if not component and not rate:
        print('Invalid parameter for numbers of components!')
        sys.exit(0)
    elif component:
        print('Choosing by component, components are %s......' % component)
        return component
    else:
        print('Choosing by rate, rate is %s ......' % rate)
        for i in range(1, len(lst)):
            if sum(lst[:i]) / sum(lst) >= rate:
                return i
        return 0



mat = np.array(featAll)
Mat = np.array(mat, dtype='float64')
print np.shape(Mat)
p, n = np.shape(Mat)  # shape of Mat
t = np.mean(Mat, 0)  # mean of each column
for i in range(p):
    for j in range(n):
        Mat[i, j] = float(Mat[i, j] - t[j])
cov_Mat = np.dot(Mat.T, Mat) / (p - 1)
U, V = np.linalg.eigh(cov_Mat)
U = U[::-1]
for i in range(n):
    V[i, :] = V[i, :][::-1]
Index = index_lst(U, component=128)
if Index:
    v = V[:, :Index]  # subset of Unitary matrix
else:
    print('Invalid rate choice.\nPlease adjust the rate.')
    print('Rate distribute follows:')
    print([sum(U[:i]) / sum(U) for i in range(1, len(U) + 1)])
    sys.exit(0)
T1 = np.dot(Mat, v)
#print(T1)
print(np.shape(T1))


