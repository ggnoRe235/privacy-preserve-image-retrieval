import numpy as np
import os
import shutil
import math
from PIL import Image
import glob

def encryption1(key, start=500, x0=0.1):
    for _ in range(start):
        x = key * x0 * (1 - x0)
        x0 = x
    return x,x0


def encryption2(imgpath,x,x0):
    tempList = imgpath.split('\\')
    name = tempList[len(tempList)-1]
    name = name.split('.')[0]
    name = name + '.bmp'
    name_ = ''
    for i in range(0,len(tempList)-1):
        name_ = name_ + tempList[i] + '\\'
    name = name_ + name

    img = Image.open(imgpath)
    img_en = Image.new(mode=img.mode, size=img.size)
    width, height = img.size
    chaos_seq = np.zeros(width * height)
    for i in range(width * height):
        x = key * x0 * (1 - x0)
        x0 = x
        chaos_seq[i] = x
    idxs_en = np.argsort(chaos_seq)
    i, j = 0, 0
    for idx in idxs_en:
        col = int(idx % width)
        row = int(idx // width)
        img_en.putpixel((i, j), img.getpixel((col, row)))
        i += 1
        if i >= width:
            j += 1
            i = 0
    img_en.save(name)
    print name


def walk(path, nodeList):
    for root, dirs, files in os.walk(path):
        for file in files:
            if '.txt' in file:
                nodeList.append(os.path.join(root, file))


configFile = open('config.txt', 'r')
config = configFile.read()
configFile.close()
n = int(config.split('\n')[0])
key = np.float(config.split('\n')[7])

S = np.random.randint(0, 2, n)
M1 = np.random.randint(0, 2, (n, n))
M2 = np.random.randint(0, 2, (n, n))
# file = open('G:/pictures/S.txt','w')


nodeList = []

shutil.rmtree(config.split('\n')[6])
#os.mkdir(config.split('\n')[6])

# for name in os.listdir(config.split('\n')[5]):
#     shutil.copy(config.split('\n')[5] + name, config.split('\n')[6])

shutil.copytree(config.split('\n')[5], config.split('\n')[6])

np.savetxt(config.split('\n')[5] + 'S.txt', S)
np.savetxt(config.split('\n')[5] + 'M1.txt', M1)
np.savetxt(config.split('\n')[5] + 'M2.txt', M2)

walk(config.split('\n')[6], nodeList)

for name in nodeList:
    if not 'record' in name:
        file = open(name, 'r')
        content = file.read()
        RvCode1 = content.split('\n')[0]
        if len(content.split('\n')) == 1:
            E_set = ''
            IND = ''
        else:
            E_set = content.split('\n')[1]
            IND = content.split('\n')[2]
        file.close()
        RvArr1 = map(''.join, zip(*[iter(RvCode1)] * 1))
        RvArr1 = map(int, RvArr1)
        # RvArr1 = np.array(list(map(int,RvCode1))).astype(int)
        RvArr1[RvArr1 <= 0] = -1
        RvArr11 = np.zeros(n).astype(int)
        RvArr12 = np.zeros(n).astype(int)
        for i in range(0, n):
            if S[i] == 0:
                if RvArr1[i] == 1:
                    num1 = np.random.randint(100)
                    num2 = num1 * (-1) + 1
                    if (np.random.randint(2) == 0):
                        RvArr11[i] = num1
                        RvArr12[i] = num2
                    else:
                        RvArr11[i] = num2
                        RvArr12[i] = num1
                elif RvArr1[i] == -1:
                    num1 = np.random.randint(100)
                    num2 = num1 * (-1) - 1
                    if (np.random.randint(2) == 0):
                        RvArr11[i] = num1
                        RvArr12[i] = num2
                    else:
                        RvArr11[i] = num2
                        RvArr12[i] = num1
            else:
                RvArr11[i] = RvArr1[i]
                RvArr12[i] = RvArr1[i]

        # RvArr11 = RvArr11.astype(str)
        # RvArr12 = RvArr12.astype(str)

        # RvArr11 = np.vstack((RvArr11,RvArr12))
        EncRv1 = np.hstack((np.dot(M1.T, RvArr11), np.dot(M2.T, RvArr12)))
        EncRv1 = EncRv1.astype(str)
        line = ','.join(EncRv1)
        file = open(name, 'w')
        file.write(line)
        file.close()
        if E_set != '':
            outputFile = open(name, 'a+')
            outputFile.write('\n' + E_set + '\n')
            outputFile.write(IND)
            outputFile.close()

        # outputFile = open(name,'w')
        # outputFile.write(np.array(RvArr11.tolist()).tostring() + '\n')
        # if E_set!='':
        #    outputFile.write(np.array(RvArr12.tolist()).tostring() + '\n')
        #    outputFile.write(E_set + '\n')
        #    outputFile.write(IND)
        # else:
        #    outputFile.write(np.array(RvArr12.tolist()).tostring())
        # outputFile.close()
        # file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        # arr = file.read().split('\n')[0]
        # file.close()
        # arr = map(''.join, zip(*[iter(arr)] * 1))
        # arr = map(int, arr)
        # dis = Distance(Q[0], arr)
    else:
        newRv = ''
        file = open(name, 'r')
        strList = file.read().split('\n')
        file.close()
        file = open(name, 'w')
        file.write('')
        file.close()
        file = open(name, 'a+')
        for Str in strList:
            if Str != '':
                Str = map(''.join, zip(*[iter(Str)] * 1))
                RvArr1 = map(int, Str)
                RvArr1[RvArr1 <= 0] = -1
                RvArr11 = np.zeros(n).astype(int)
                RvArr12 = np.zeros(n).astype(int)
                for i in range(0, n):
                    if S[i] == 0:
                        if RvArr1[i] == 1:
                            num1 = np.random.randint(100)
                            num2 = num1 * (-1) + 1
                            if (np.random.randint(2) == 0):
                                RvArr11[i] = num1
                                RvArr12[i] = num2
                            else:
                                RvArr11[i] = num2
                                RvArr12[i] = num1
                        elif RvArr1[i] == -1:
                            num1 = np.random.randint(100)
                            num2 = num1 * (-1) - 1
                            if (np.random.randint(2) == 0):
                                RvArr11[i] = num1
                                RvArr12[i] = num2
                            else:
                                RvArr11[i] = num2
                                RvArr12[i] = num1
                    else:
                        RvArr11[i] = RvArr1[i]
                        RvArr12[i] = RvArr1[i]

                # RvArr11 = RvArr11.astype(str)
                # RvArr12 = RvArr12.astype(str)

                # RvArr11 = np.vstack((RvArr11, RvArr12))
                EncRv1 = np.hstack((np.dot(M1.T, RvArr11), np.dot(M2.T, RvArr12)))
                EncRv1 = EncRv1.astype(str)
                line = ','.join(EncRv1)
                file.write(line + '\n')

        #         if newRv=='':
        #             newRv = EncRv1
        #         else:
        #             newRv = np.vstack((newRv,EncRv1))
        # np.savetxt(name, newRv, delimiter=',')
        file.close()


pictureList = []

g = os.walk(config.split('\n')[6])
for path,d,filelist in g:
    for filename in filelist:
        if filename.endswith('jpg'):
            pictureList.append(os.path.join(path, filename))

# x,x0=encryption1(key)
# for impath in pictureList:
#     encryption2(impath,x,x0)
#     os.remove(impath)

