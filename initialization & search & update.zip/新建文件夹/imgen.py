import numpy as np
from PIL import Image

def encryption(key, imgpath, start=500, x0=0.1):
	if key > 4 or key < 3.57:
		print('[Error]: Key must between <3.57-4>...')
		return None
	if x0 >= 1 or x0 <= 0:
		print('[Error]: x0 must between <0-1>...')
		return None
	img = Image.open(imgpath)
	img_en = Image.new(mode=img.mode, size=img.size)
	width, height = img.size
	chaos_seq = np.zeros(width * height)
	for _ in range(start):
		x = key * x0 * (1 - x0)
		x0 = x
	for i in range(width * height):
		x = key * x0 * (1 - x0)
		x0 = x
		chaos_seq[i] = x
	idxs_en = np.argsort(chaos_seq)
	i, j = 0, 0
	for idx in idxs_en:
		col = int(idx % width)
		row = int(idx // width)
		img_en.putpixel((i, j), img.getpixel((col, row)))
		i += 1
		if i >= width:
			j += 1
			i = 0
	img_en.save('encryption2.bmp')
	#return idxs_en


def decryption(key, imgpath, start=500, x0=0.1):
	if key > 4 or key < 3.57:
		print('[Error]: Key must between <3.57-4>...')
		return None
	if x0 >= 1 or x0 <= 0:
		print('[Error]: x0 must between <0-1>...')
		return None
	img = Image.open(imgpath)
#	img = img_en
 	img_de = Image.new(mode=img.mode, size=img.size)
	width, height = img.size
	chaos_seq = np.zeros(width * height)
	for _ in range(start):
		x = key * x0 * (1 - x0)
		x0 = x
	for i in range(width * height):
		x = key * x0 * (1 - x0)
		x0 = x
		chaos_seq[i] = x
	idxs_de = np.argsort(chaos_seq)
	i, j = 0, 0
	for idx in idxs_de:
		col = int(idx % width)
		row = int(idx // width)
		img_de.putpixel((col, row), img.getpixel((i, j)))
		i += 1
		if i >= width:
			j += 1
			i = 0
	img_de.save('decryption.jpg')
	#return idxs_de



encryption(key=float(3.584864245), imgpath='space_shuttle.jpg')
decryption(key=float(3.584864245), imgpath='encryption2.bmp')