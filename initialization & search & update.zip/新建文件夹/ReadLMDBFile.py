import caffe
from caffe.proto import caffe_pb2
import lmdb
import os
import cv2
import numpy as np
import shutil
import glob
import matlab.engine


configFile = open('config.txt','r')
config = configFile.read()
configFile.close()

pictureList = glob.glob(config.split('\n')[3]+"*/*.jpg")
outputFile1 = open('F:/file_list.txt', 'w')
for pic in pictureList:
    outputFile1.write(pic + ' 0\n')
outputFile1.close()

shutil.rmtree('F:/temp')
num = str(int(config.split('\n')[1]) * 50)
command = 'F:/caffe-windows/scripts/build/tools/Release/extract_features.exe F:/caffe-windows/examples/myExample_iter_431534.caffemodel F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt fc7 F:/temp '+num+' lmdb GPU 0'
os.system(command)

lmdb_env = lmdb.open('F:/temp', readonly=True)
lmdb_txn = lmdb_env.begin()
lmdb_cursor = lmdb_txn.cursor()
datum = caffe_pb2.Datum()
imgeCnt=0
f2 = open('feature.csv','w')
for key, value in lmdb_cursor:
    datum.ParseFromString(value)
    label = datum.label
    data = caffe.io.datum_to_array(datum)
    DIM = datum.channels
    imgeCnt=imgeCnt+1
    if (imgeCnt%100==0):
        print("imgeCnt="+str(imgeCnt))
    for i in range(DIM-1):
       f2.write (str(data[i][0][0])+", ")
    f2.write (str(data[DIM-1][0][0])+"\n")

lmdb_env.close()
f2.close()
print (imgeCnt)

eng = matlab.engine.start_matlab()
ret = eng.Process(int(config.split('\n')[0]))
eng.quit()
print (ret)

a= np.loadtxt('B.csv',int,delimiter=',')
outputFile = open('outputFile1.txt','w')

for i in range(0,int(config.split('\n')[1]) * 50):
     tempArr = a[i]
     tempList = list(tempArr)
     tempList = map(int,tempList)
     tempList = map(str,tempList)
     #print tempList
     result = ''.join(tempList)
     #print result
     outputFile.write(result+"\n")
outputFile.close()