from sklearn.cluster import KMeans
from sklearn.externals import joblib
from sklearn import cluster
import numpy as np
import shutil
import os
import random

n_clusters = 50
nbits = 128
Tht = 0.38


inputFile = open('E:/PyCharm/untitled/outputFile.txt','r')
inputData = inputFile.read()
inputFile.close()
list = inputData.split('\n')

num = np.shape(list)[0]

arr = map(''.join , zip(*[iter(list[0])]*1))
arr = map(int, arr)

for i in range(1,num-1):
    Str = list[i]
    tempList = map(''.join , zip(*[iter(Str)]*1))
    tempList = map(int, tempList)
    arr = np.vstack((arr,tempList))



estimator = KMeans(n_clusters)

res = estimator.fit_predict(arr)
label_pred = estimator.labels_
centroids = estimator.cluster_centers_
inertia = estimator.inertia_

CountOfFile = 0
CountOfDir = 0

SourceDir = 'G:/train2/'
#SourceDirEnd = ['001.ak47/','002.american-flag/','003.backpack/','004.baseball-bat/','005.baseball-glove/','006.basketball-hoop/','007.bat/','008.bathtub/','009.bear/','010.beer-mug/','011.billiards/','012.binoculars/','013.birdbath/','014.blimp/','015.bonsai-101/','016.boom-box/','017.bowling-ball/','018.bowling-pin/','019.boxing-glove/','020.brain-101/','021.breadmaker/','022.buddha-101/','023.bulldozer/','024.butterfly/','025.cactus/','026.cake/','027.calculator/','028.camel/','029.cannon/','030.canoe/']
SourceDirEnd = os.listdir(SourceDir)
for i in range(0,len(SourceDirEnd)):
    SourceDirEnd[i] = SourceDirEnd[i] + '/'
TargetDir = 'G:/pictures/'

TargetDirEnd = []
RecordName = []
RvFile = []
for i in range(0,n_clusters):
    TargetDirEnd.append('0,'+str(i)+'/')
    RecordName.append('0,'+str(i)+'.txt')
    RvFile.append(open('G:/pictures/0,'+ str(i) + 'record.txt','a'))



FileName = ''
for number in label_pred:
    if CountOfFile == 50:
        CountOfFile = 0
        CountOfDir = CountOfDir + 1
    CountOfFile = CountOfFile + 1
    FileName = ''
    if CountOfFile <=9:
        if CountOfDir + 1 <=9:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_000' + str(CountOfFile) + '.jpg'
            #print FileName
        else:
            FileName = FileName +SourceDirEnd[CountOfDir].split('.')[0] + '_000' + str(CountOfFile) + '.jpg'
            #print FileName

    else:
        if CountOfDir + 1  <= 9:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_00' + str(CountOfFile) + '.jpg'
            #print FileName
        else:
            FileName = FileName + SourceDirEnd[CountOfDir].split('.')[0] + '_00' + str(CountOfFile) + '.jpg'
            #print FileName
    Source = SourceDir + SourceDirEnd[CountOfDir] + FileName
    Target = TargetDir + TargetDirEnd[number] + FileName
    shutil.copy(Source,Target)

new_RV = np.zeros((n_clusters,nbits))
cluster_num = np.zeros(n_clusters)
nSamples = np.shape(label_pred)[0]


for i in range(0,nSamples):
    if(cluster_num[label_pred[i]]<40):
        new_RV[label_pred[i]] = new_RV[label_pred[i]] + arr[i]
        cluster_num[label_pred[i]] = cluster_num[label_pred[i]] + 1
    file = RvFile[label_pred[i]]
    tempstr = arr[i].astype(int)
    tempstr = tempstr.astype(str)
    file.write(np.array(tempstr.tolist()).tostring()+'\n')
    #cluster_num[label_pred[i]] = cluster_num[label_pred[i]] + 1

for i in range(0,n_clusters):
    new_RV[i] = new_RV[i] / cluster_num[i]
    #print cluster_num[i]

for i in range(0,n_clusters):
    RvFile[i].close()

new_RV[new_RV>=0.6] = 1
new_RV[new_RV<0.6] = 0

new_RV = new_RV.astype(int)
new_RV = new_RV.astype(str)
#print new_RV



for i in range(0,n_clusters):
    OutputFile = open(TargetDir+TargetDirEnd[i]+RecordName[i],'a')
    OutputFile.write(np.array(new_RV[i].tolist()).tostring()+'\n')
    OutputFile.write('0,'+str(i)+'|'+'\n') #E set
    OutputFile.write('0')#+'\n') #IND
    OutputFile.close()
    OutputFile = open('G:/pictures/' + RecordName[i],'a')
    OutputFile.write(np.array(new_RV[i].tolist()).tostring())
    OutputFile.close()



C_Set = []
for i in range(0,n_clusters):
    C_Set.append(TargetDir+TargetDirEnd[i])


def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance


def FindNearest(C_Set):
    RecordMatrix = np.zeros((len(C_Set),len(C_Set)),int)

    minLevel = 9999
    for text in C_Set:
        if int(text.split('/')[2].split(',')[0]) < minLevel:
            minLevel = int(text.split('/')[2].split(',')[0])

    for i in range(0,len(C_Set)):
        file1 = open(C_Set[i]+C_Set[i].split('/')[2]+'.txt','r')
        #print C_Set[i]+C_Set[i].split('/')[2]+'.txt'
        str1 = file1.read().split('\n')[0]
        arr1 = map(''.join, zip(*[iter(str1)] * 1))
        arr1 = map(int, arr1)
        file1.close()
        for m in range(0,len(C_Set)):
            file2 = open(C_Set[m]+C_Set[m].split('/')[2]+'.txt','r')
            str2 = file2.read().split('\n')[0]
            arr2 = map(''.join, zip(*[iter(str2)] * 1))
            arr2 = map(int, arr2)
            file2.close()
            distance = Distance(arr1,arr2)
            RecordMatrix[i][m] = distance
            Cu = C_Set[i]
            Cv = C_Set[m]
            file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVu = content.split('\n')[0]
            RVu = map(''.join, zip(*[iter(RVu)] * 1))
            RVu = map(int, RVu)
            INDu = int(content.split('\n')[2])
            Esetu = len(content.split('\n')[1].split('|'))
            file.close()
            file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVv = content.split('\n')[0]
            RVv = map(''.join, zip(*[iter(RVv)] * 1))
            RVv = map(int, RVv)
            INDv = int(content.split('\n')[2])
            Esetv = len(content.split('\n')[1].split('|'))
            file.close()
            if C_Set[i].split('/')[2].split(',')[0] == C_Set[m].split('/')[2].split(',')[0] and C_Set[i].split('/')[2].split(',')[0]!='0':
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                if DM >= Tht:
                    RecordMatrix[i][m] = distance
                else:
                    RecordMatrix[i][m] = 9999999
            else:
                RecordMatrix[i][m] = distance

            if Esetu>=4:
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                levelu = int(C_Set[i].split('/')[2].split(',')[0])
                levelv = int(C_Set[m].split('/')[2].split(',')[0])
                if DM<Tht and levelu > levelv:
                    RecordMatrix[i][m] = 9999999
            if Esetv >= 4:
                max_value = max(INDu, INDv) * 1.0
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                levelu = int(C_Set[i].split('/')[2].split(',')[0])
                levelv = int(C_Set[m].split('/')[2].split(',')[0])
                if DM < Tht and levelu < levelv:
                    RecordMatrix[i][m] = 9999999

                #RecordMatrix[i][m] = 9999999
    print RecordMatrix


    #print RecordMatrix
    Min = 99999999
    x = 0
    y = 0
    for i in range(0,len(C_Set)):
        for m in range(0,len(C_Set)):
            if i!=m and RecordMatrix[i][m]<Min:
                x = i
                y = m
                Min = RecordMatrix[i][m]
            elif i!=m and RecordMatrix[i][m]==Min:
            #     #print C_Set[i]
            #     #print C_Set[m]
            #
                 level0 = int((C_Set[x].split('/')[2]).split(',')[0])
                 level1 = int((C_Set[y].split('/')[2]).split(',')[0])
                 level2 = int((C_Set[i].split('/')[2]).split(',')[0])
                 level3 = int((C_Set[m].split('/')[2]).split(',')[0])
                 max1 = max(level0,level1)
                 min1 = min(level0,level1)
                 max2 = max(level2,level3)
                 min2 = min(level2,level3)
                 if(max1 < max2):
                     x = i
                     y = m
            #     elif(max1 == max2 and min2 < min1):
            #         x = i
            #         y = m
    #print RecordMatrix
    return x,y

LevelCount = [n_clusters]

def merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,flag):
    if flag == True:
        newLevel = max(levelu,levelv) + 1
        dirName = ''
        if newLevel > len(LevelCount)-1:
            LevelCount.append(1)
            dirName = str(newLevel)+','+str(LevelCount[newLevel]-1)
        elif newLevel <=len(LevelCount)-1:
            LevelCount[newLevel] = LevelCount[newLevel]+1
            dirName = str(newLevel) + ',' + str(LevelCount[newLevel] - 1)
        file = open(Cu+Cu.split('/')[2]+'.txt','r')
        E_Setu = file.read().split('\n')[1].split('|')
        file.close()
        file = open(Cv+Cv.split('/')[2]+'.txt','r')
        E_Setv = file.read().split('\n')[1].split('|')
        file.close()
        newE_Set = ''
        for Str in E_Setu:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        for Str in E_Setv:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        newIND = max(INDu,INDv,Distance(RVu,RVv))

        # disList = []
        # for name1 in newE_Set.split('|'):
        #     for name2 in newE_Set.split('|'):
        #         if name1!=name2 and name1!='' and name2!='':
        #             file1 = open('G:/pictures/'+name1+'record.txt','r')
        #             file2 = open('G:/pictures/'+name2+'record.txt','r')
        #             RV1 = file1.read().split('\n')[0]
        #             RV2 = file2.read().split('\n')[1]
        #             file1.close()
        #             file2.close()
        #             RV1 = map(''.join, zip(*[iter(RV1)] * 1))
        #             RV1 = map(int, RV1)
        #             RV2 = map(''.join, zip(*[iter(RV2)] * 1))
        #             RV2 = map(int, RV2)
        #             disList.append(Distance(RV1,RV2))
        # newIND = max(disList)

        arr = np.zeros(nbits)#,int)
        TList = []
        count = 0
        for Str in newE_Set.split('|'):
            if Str!='':
                file = open('G:/pictures/' + Str + 'record.txt','r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    TList.append(rv)
                    count = count + 1

        NoList  = random.sample(range(0,count),40)
        for no in NoList:
            rv = TList[no]
            tempList = map(''.join, zip(*[iter(rv)] * 1))
            tempList = map(int, tempList)
            arr = arr + tempList

        arr = arr / 40#count
        arr[arr >= 0.6] = 1
        arr[arr < 0.6] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        os.mkdir('G:/pictures/'+dirName)
        shutil.move(Cu,'G:/pictures/'+dirName)
        shutil.move(Cv,'G:/pictures/'+dirName)
        C_Set.append('G:/pictures/'+dirName+'/')
        C_Set.remove(Cu)
        C_Set.remove(Cv)

        OutputFile = open('G:/pictures/'+dirName+'/'+dirName+'.txt', 'a')
        OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
        OutputFile.write(newE_Set+'\n')
        OutputFile.write(str(newIND))
        OutputFile.close()
        #print newIND



    else:
        newE_Set = ''
        newIND = max(INDu,INDv,Distance(RVu,RVv))
        #newIND = Distance(RVu,RVv)
        file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
        E_Setu = file.read().split('\n')[1].split('|')
        file.close()
        file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
        E_Setv = file.read().split('\n')[1].split('|')
        file.close()
        for Str in E_Setu:
            if Str!= '':
                newE_Set = newE_Set + Str + '|'
        for Str in E_Setv:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        arr = np.zeros(nbits)#, int)
        count = 0

        # disList = []
        # for name1 in newE_Set.split('|'):
        #     for name2 in newE_Set.split('|'):
        #         if name1!=name2:
        #             file1 = open('G:/pictures/'+name1+'record.txt','r')
        #             file2 = open('G:/pictures/'+name2+'record.txt','r')
        #             RV1 = file1.read().split('\n')[0]
        #             RV2 = file2.read().split('\n')[1]
        #             file1.close()
        #             file2.close()
        #             RV1 = map(''.join, zip(*[iter(RV1)] * 1))
        #             RV1 = map(int, RV1)
        #             RV2 = map(''.join, zip(*[iter(RV2)] * 1))
        #             RV2 = map(int, RV2)
        #             disList.append(Distance(RV1,RV2))
        # newIND = max(disList)

        TList = []
        count = 0

        for Str in newE_Set.split('|'):
            if Str != '':
                file = open('G:/pictures/' + Str + 'record.txt', 'r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    TList.append(rv)
                    count = count + 1

        NoList = random.sample(range(0, count), 40)
        for no in NoList:
            rv = TList[no]
            tempList = map(''.join, zip(*[iter(rv)] * 1))
            tempList = map(int, tempList)
            arr = arr + tempList
        arr = arr / 40#count
        arr[arr >= 0.6] = 1
        arr[arr < 0.6] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        if levelu > levelv:
            OutputFile = open(Cu+Cu.split('/')[2]+'.txt','w+')
            OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
            OutputFile.write(newE_Set + '\n')
            OutputFile.write(str(newIND))
            OutputFile.close()
            C_Set.remove(Cv)
            shutil.move(Cv,Cu)

        elif levelu<levelv:
            OutputFile = open(Cv+Cv.split('/')[2]+'.txt','w+')
            OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
            OutputFile.write(newE_Set + '\n')
            OutputFile.write(str(newIND))
            OutputFile.close()
            C_Set.remove(Cu)
            shutil.move(Cu,Cv)
        elif levelu == levelv:
            idu = int((Cu.split('/')[2]).split(',')[1])
            idv = int((Cv.split('/')[2]).split(',')[1])
            if idu > idv:
                OutputFile = open(Cu + Cu.split('/')[2] + '.txt', 'w+')
                OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
                OutputFile.write(newE_Set + '\n')
                OutputFile.write(str(newIND))
                OutputFile.close()
                C_Set.remove(Cv)
                os.remove(Cv+Cv.split('/')[2]+'.txt')
                for files in os.listdir(Cv):
                    shutil.move(Cv + files, Cu)
                os.rmdir(Cv)
            else:
                OutputFile = open(Cv + Cv.split('/')[2] + '.txt', 'w+')
                OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
                OutputFile.write(newE_Set + '\n')
                OutputFile.write(str(newIND))
                OutputFile.close()
                C_Set.remove(Cu)
                os.remove(Cu+Cu.split('/')[2]+'.txt')
                for files in os.listdir(Cu):
                    shutil.move(Cu + files, Cv)
                os.rmdir(Cu)
    return C_Set


LevelCount = [n_clusters]


while len(C_Set)>1:
    if len(C_Set) > 2:
        x,y = FindNearest(C_Set)
    else:
        x = 0
        y = 1
    Cu = C_Set[x]
    Cv = C_Set[y]
    file = open(Cu+Cu.split('/')[2]+'.txt','r')
    content = file.read()
    RVu = content.split('\n')[0]
    RVu = map(''.join, zip(*[iter(RVu)] * 1))
    RVu = map(int, RVu)
    levelu = int((Cu.split('/')[2]).split(',')[0])
    INDu = int(content.split('\n')[2])
    file.close()
    file = open(Cv+Cv.split('/')[2]+'.txt','r')
    content = file.read()
    RVv = content.split('\n')[0]
    RVv = map(''.join, zip(*[iter(RVv)] * 1))
    RVv = map(int, RVv)
    levelv = int((Cv.split('/')[2]).split(',')[0])
    INDv = int(content.split('\n')[2])
    file.close()
    if INDu==0 and INDv==0:
        C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
        print Cu + ' + ' + Cv + ' -> new'
    else:
        max_value = max(INDu,INDv) * 1.0
        dis = Distance(RVu,RVv) * 1.0
        #print type(max_value)
        #print type(dis)
        DM = (abs(dis - max_value))/max_value
        #print type(DM)
        if DM >= Tht:
            print Cu + ' + ' + Cv + ' -> new'
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
        else:
            print Cu + ' -> ' + Cv
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,False)

    #print C_Set
    raw_input()






