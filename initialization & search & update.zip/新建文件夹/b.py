import numpy as np
import math

# calculate hamming distance between 2 RV vectors

n = 128

RvCode1 = '01001101101111100001100111110011111101110011011100010001000011011111111001010100100101100101100111011001100011100000001101110010'
RvCode2 = '11011100011111101000100011001001001101010001011100011101000011011011101111110100100010100101100101011101100001100000101101110011'

# without Rv1 and Rv2 onlt store Rv1' Rv2'

RvArr1 = np.array(list(map(int,RvCode1))).astype(int)
RvArr2 = np.array(list(map(int,RvCode2))).astype(int)
cc = 0
for i in range(0,128):
    if RvCode1[i]!=RvCode2[i]:
        cc = cc+1

RvArr1[RvArr1<=0] = -1
RvArr2[RvArr2<=0] = -1

#print RvArr1

# before all the other steps, we could use unencrypted Rv' vector to calculate distance
distance1 = (n - (np.dot(RvArr1,RvArr2.T))) / 2
#print distance1

# Split vector S  (nbits)

S = np.random.randint(0,2,n)

#print(S)

# FOR RV1
# if S[i] equals 0
# if RvArr1[i] equals 1
# get random from 0 to 1, if random equals 0, then the first vector[i] shall be 1
# while the second vector[i] shall be 0
# if random equals 1, then the first vector[i] shall be 0
# while the second vector[i] shall be 1

# if S[i] equals 1
# then two vectors spilt from RV1 shall be the same at ith

# the situation for RV2 is just different from RV1


RvArr11 = np.zeros(n).astype(int)
RvArr12 = np.zeros(n).astype(int)
RvArr21 = np.zeros(n).astype(int)
RvArr22 = np.zeros(n).astype(int)

#print RvArr11
#print RvArr12


for i in range(0,128):
    if S[i] == 0:
        RvArr21[i] = RvArr2[i]
        RvArr22[i] = RvArr2[i]
        if RvArr1[i] == 1:
            num1 = np.random.randint(100)
            num2 = num1*(-1) + 1
            if(np.random.randint(2)==0):
                RvArr11[i] = num1
                RvArr12[i] = num2
            else:
                RvArr11[i] = num2
                RvArr12[i] = num1
        elif RvArr1[i] == -1:
            num1 = np.random.randint(100)
            num2 = num1*(-1) - 1
            if(np.random.randint(2)==0):
                RvArr11[i] = num1
                RvArr12[i] = num2
            else:
                RvArr11[i] = num2
                RvArr12[i] = num1

    else:
        RvArr11[i] = RvArr1[i]
        RvArr12[i] = RvArr1[i]
        if RvArr2[i] == 1:
            num1 = np.random.randint(100)
            num2 = num1*(-1) + 1
            if(np.random.randint(2)==0):
                RvArr21[i] = num1
                RvArr22[i] = num2
            else:
                RvArr21[i] = num2
                RvArr22[i] = num1
        elif RvArr2[i] == -1:
            num1 = np.random.randint(100)
            num2 = num1*(-1) - 1
            if(np.random.randint(2)==0):
                RvArr21[i] = num1
                RvArr22[i] = num2
            else:
                RvArr21[i] = num2
                RvArr22[i] = num1


#print RvArr11
#print RvArr12

## verification function
# flag = 1
# # verification
# for i in range(0,128):
#     if S[i] ==0:
#         if RvArr1[i]!=RvArr11[i]+RvArr12[i]:
#             flag = 0
#             print 'fault1'
#     else:
#         if RvArr1[i]!= RvArr11[i] or RvArr1[i]!=RvArr12[i]:
#             flag = 0
#             print 'fault2'
#
# if flag == 1:
#     print 'success'

# two random matrices M1 and M2 as encrypted matrices

M1 = np.random.randint(0,2,(n,n))
M2 = np.random.randint(0,2,(n,n))
#print M1
#print np.linalg.inv(M1)

EncRv1 = np.hstack((np.dot(M1.T,RvArr11),np.dot(M2.T,RvArr12)))
print np.shape(EncRv1)
EncRv2 = np.hstack((np.dot(np.linalg.inv(M1),RvArr21),np.dot(np.linalg.inv(M2),RvArr22)))

distance2 = np.int(np.round((n-(np.dot(EncRv1.T,EncRv2)))/2))

print EncRv1
print EncRv2
print distance1
print distance2



print cc


# two ways to get hamming distance
# when generating the index tree, we could use the method1(unencrypted rv)
# while when searching, we get to use the second way, client only send EncRv1 and EncRv2 to cloud
# the two encrypted matrix could change extremely while the hamming distance still remain static(existing small loss because of np.linalg.inv function has loss)