import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
# try trainPCAH.m
import glob
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
import sys
import os
import caffe
import pickle
from sklearn.datasets import make_blobs
from sklearn.decomposition import PCA

def decode(s):
    return ''.join([chr(i) for i in [int(b, 2) for b in s.split(' ')]])

plt.rcParams['figure.figsize']=(12,12)
plt.rcParams['figure.dpi']=150
plt.rcParams['image.interpolation']='nearest'
plt.rcParams['image.cmap']='jet'
caffe_root='G:/caffe/'
model_root='G:/caffe/models/'
caffe.set_mode_cpu()
model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
#model_def = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.prototxt'
#model_weights = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel'
net = caffe.Net(model_def,
                model_weights,
                caffe.TEST)
net.blobs['data'].reshape(10,3,227,227)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))


#pictureList = ['cat.jpg','cat2.jpg','fish-bike.jpg','cat gray.jpg','cat_gray.jpg']#,'fish-bike.jpg','cat gray.jpg','cat_gray.jpg'}

pictureList = glob.glob(r"G:/256_ObjectCategories/*/*.jpg")
#pictureList = glob.glob(r"G:/caffe/examples/images/*.jpg")
#print pictureList
#print pictureList

featAll = []

for pic in pictureList:
    print pic
    #image = caffe.io.load_image('G:/caffe/examples/images/'+pic)
    image = caffe.io.load_image(pic)
    transformed_image=transformer.preprocess('data',image)
    net.blobs['data'].data[...] = transformed_image
    output = net.forward()
    feature = net.blobs['fc7'].data[0]
    #feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
    #print feature_standarlized
    #tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
    tmpf = feature.reshape(1, feature.size)
    #print tmpf
    #tmpf = feature.reshape(1,feature.size)
    s=tmpf.tolist()
    fe=reduce(lambda x,y:x+y,s)
    #print fe

#    print(fe)
#print len(fe)
#print type(fe)
#print(fe)
    featAll.append(fe)

reg = 0.0001

X = featAll
print np.shape(X)
Y = np.zeros((np.shape(X)[0],2),float)

count = 0

for i in range(1,np.shape(X)[0]+1):
    Y[i-1][count] = 1
    if i % 60==0:
        count = count + 1
    if count == 2:
        break

z = np.column_stack((X,Y))
C = np.cov(z)
sx = np.shape(X)[1]
sy = np.shape(Y)[1]
print np.shape(C[0:sx,0:sx])
print sx
print np.shape(eye(sx))
Cxx = (C[0:sx][:,0:sx]) + (reg*np.eye(sx))
Cxy = C[0:sx][:,sx:(sx+sy)]
Cyx = np.transpose(Cxy)
Cyy = C[sx:(sx+sy)][:,sx:(sx+sy)] + reg * np.eye(sy)

Rx = np.transpose(np.linalg.cholesky(Cxx))
invRx = np.linalg.inv(Rx)
Z = np.dot(np.dot(np.dot(np.transpose(invRx),Cxy),np.linalg.solve(Cyy,Cyx)),invRx)
Z = 0.5 * (np.transpose(Z) + Z)

r,Wx = np.linalg.eig(Z)
r = sqrt(real(r))
Wx = np.dot(invRx,Wx)
r = diag(r)


index = np.argsort(-r,axis = 0)
r.sort(axis=0)
r_ = np.full_like(r,0)
for i in range(0,np.shape(r)[0]):
    for m in range(0,np.shape(r)[1]):
        r_[np.shape(r)[0]-1-i][m] = r[i][m]

r = r_

print np.shape(Wx)
print np.shape(index)
print np.shape(r)