import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
# try trainPCAH.m
import glob
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
import sys
import os
import caffe
import pickle
from sklearn.datasets import make_blobs
from sklearn.decomposition import PCA
#
# def decode(s):
#     return ''.join([chr(i) for i in [int(b, 2) for b in s.split(' ')]])
#
# plt.rcParams['figure.figsize']=(12,12)
# plt.rcParams['figure.dpi']=150
# plt.rcParams['image.interpolation']='nearest'
# plt.rcParams['image.cmap']='jet'
# caffe_root='G:/caffe/'
# model_root='G:/caffe/models/'
# caffe.set_mode_cpu()
# model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
# model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
# #model_def = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.prototxt'
# #model_weights = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel'
# net = caffe.Net(model_def,
#                 model_weights,
#                 caffe.TEST)
# net.blobs['data'].reshape(10,3,227,227)
# transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
# transformer.set_transpose('data',(2,0,1))
# transformer.set_raw_scale('data',255)
# transformer.set_channel_swap('data',(2,1,0))
#
#
# #pictureList = ['cat.jpg','cat2.jpg','fish-bike.jpg','cat gray.jpg','cat_gray.jpg']#,'fish-bike.jpg','cat gray.jpg','cat_gray.jpg'}
#
# pictureList = glob.glob(r"G:/256_ObjectCategories/*/*.jpg")
# #pictureList = glob.glob(r"G:/caffe/examples/images/*.jpg")
# #print pictureList
# #print pictureList
#
# featAll = []
#
# for pic in pictureList:
#     print pic
#     #image = caffe.io.load_image('G:/caffe/examples/images/'+pic)
#     image = caffe.io.load_image(pic)
#     transformed_image=transformer.preprocess('data',image)
#     net.blobs['data'].data[...] = transformed_image
#     output = net.forward()
#     feature = net.blobs['fc7'].data[0]
#     #feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
#     #print feature_standarlized
#     #tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
#     tmpf = feature.reshape(1, feature.size)
#     #print tmpf
#     #tmpf = feature.reshape(1,feature.size)
#     s=tmpf.tolist()
#     fe=reduce(lambda x,y:x+y,s)
#     #print fe
#
# #    print(fe)
# #print len(fe)
# #print type(fe)
# #print(fe)
#     featAll.append(fe)

featAll = np.loadtxt('X.csv',int,delimiter=',')

nbits = 128

# featAll = mat(featAll)
# pca = PCA(n_components=nbits)
# pca.fit(featAll)
# #V = pca.fit_transform(featAll)
# #print V
# V = pca.transform(featAll)
# pickle.dump({'pca_fit':pca},open('pc.txt','wb'))
#
# V = (V-np.mean(V,axis=0))/np.std(V,axis=0)
# print V
# Data_removed = (featAll - np.mean(featAll,axis=0))/np.std(featAll,axis=0)
# cov_Data = np.cov(Data_removed,rowvar=0)
# eigval,eigvec = np.linalg.eig(np.mat(cov_Data))
# esort = np.argsort(eigval)
# keepval = esort[:-(1+nbits):-1]
# keepvec = eigvec[:,keepval]
# V = Data_removed*keepvec


#DataAdjust = featAll - meanVals

covMat = cov(featAll,rowvar=0)
eigVals,eigVects = linalg.eig(mat(covMat))
eigValInd = argsort(eigVals)
#eigValInd = eigValInd[:-(nbits+1):-1]
eigValInd = eigValInd[:-(nbits+1):-1]
#print np.shape(eigValInd)
redEigVects = eigVects[:,eigValInd]
#print np.shape(redEigVects)
#pc = eigs(np.cov(featAll),nbits)
#print np.shape(featAll)
pc = redEigVects

V = np.dot(featAll,pc)
V = (V-np.mean(V,axis=0))/np.std(V,axis=0)

R = np.random.rand(nbits,nbits)
U11,S2,V2_ = np.linalg.svd(R)
V2 = np.transpose(V2_)
R = U11[:,0:nbits]

for i in range(0,50):
    Z = np.dot(V,R)
    #print np.shape(V)
    #print np.shape(R)
    #print np.shape(Z)
    UX = (np.full_like(Z,1)) * -1
    #print np.shape(UX)
    UX[Z>=0] = 1
    C = np.dot(np.transpose(UX),V)
    UB,sigma,UA_ = np.linalg.svd(C)
    UA = np.transpose(UA_)
    R = UA * np.transpose(UB)

#print R
#V2 = np.dot(featAll,pc)
#print V2
#V2 = np.dot(featAll[0],pc)
#U2 = np.dot(V2,R)
V = np.dot(featAll,pc)
U2 = np.dot(V,R)
temp2 = U2
temp2 = np.array(temp2)
temp2[temp2<0] = 0
temp2[temp2>0] = 1

#print np.shape(pc)
#print type(pc[0][0])
#print type(R[0][0])
#print np.shape(featAll)

np.savetxt('pc.txt',pc)
np.savetxt('r.txt',R)
#print temp2

nSamples,nbits = np.shape(temp2)
# nwords = nbits/8
# cb = zeros([nSamples,nwords],'uint8')
# for j in range(0,nbits):
#     w = int(j/8)

outputFile = open('outputFile.txt','w')

for i in range(0,nSamples):
    tempArr = np.real(temp2[i])
    #tempArr= temp2[i]
    tempList = list(tempArr)
    tempList = map(int,tempList)
    tempList = map(str,tempList)
    #print tempList
    result = ''.join(tempList)
    #print result

    outputFile.write(result+"\n")

outputFile.close()



