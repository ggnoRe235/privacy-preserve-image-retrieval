#import matlab.engine
import os
import random
import shutil

file = open('config.txt','r')
config = file.read()
nbits = int(config.split('\n')[0])
num = int(config.split('\n')[1])
Source = config.split('\n')[2]
Des1 = config.split('\n')[3]
Des2 = config.split('\n')[4]
file.close()

dirList = os.listdir(Source)
randomList  = random.sample(range(0,len(dirList)),num)

for name in os.listdir(Des1):
    shutil.rmtree(Des1 + name)
for name in os.listdir(Des2):
    shutil.rmtree(Des2 + name)

for i in range(0,len(randomList)):
    os.mkdir(Des1 + dirList[randomList[i]])
    os.mkdir(Des2 + dirList[randomList[i]])

for i in range(0,len(randomList)):
    tempList = os.listdir(Source + dirList[randomList[i]])
    length = len(tempList)
    randomList2 = random.sample(range(0,length),75)
    for m in range(0,len(randomList2)):
        if(m>24):
            shutil.copy(Source + dirList[randomList[i]] + '/' + tempList[randomList2[m]],Des1 + dirList[randomList[i]] + '/' +tempList[randomList2[m]])
        else:
            shutil.copy(Source + dirList[randomList[i]] + '/' + tempList[randomList2[m]],Des2 + dirList[randomList[i]] + '/' +tempList[randomList2[m]])




# eng = matlab.engine.start_matlab()
# ret = eng.Process(nbits)
# eng.quit()
# print (ret)

# import numpy as np
# from PIL import Image
# import random
# import imghdr
#
# img = Image.open('space_shuttle.jpg')
# imghdr.what('space_shuttle.jpg')
# width, height = img.size
# img_en = Image.new(mode=img.mode, size=img.size)
# sam  = random.sample(range(0,width*height),width*height)
# i, j = 0, 0
# for idx in sam:
#     col = int(idx % width)
#     row = int(idx // width)
#     img_en.putpixel((i, j), img.getpixel((col, row)))
#     i += 1
#     if i >= width:
#         j += 1
#         i = 0
# img_en.save('encryption.bmp')
# print np.shape(img)
# print np.shape(img_en)
#
# img2 = Image.open('encryption.bmp')
# img_de = Image.new(mode=img2.mode, size=img2.size)
# i, j = 0, 0
# for idx in sam:
#     col = int(idx % width)
#     row = int(idx // width)
#
#     img_de.putpixel((col, row), img2.getpixel((i, j)))
#     i += 1
#     if i >= width:
#         j += 1
#         i = 0
#
#
# img_de.save('decryption.jpg')
# print np.shape(img_de)
# print imghdr.what('decryption.jpg')