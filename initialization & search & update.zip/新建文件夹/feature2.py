import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
# try trainPCAH.m
import glob
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
import sys
import os
import caffe
import pickle
from sklearn.datasets import make_blobs
from sklearn.decomposition import PCA

plt.rcParams['figure.figsize']=(12,12)
plt.rcParams['figure.dpi']=150
plt.rcParams['image.interpolation']='nearest'
plt.rcParams['image.cmap']='jet'
caffe_root='G:/caffe/'
model_root='G:/caffe/models/'
caffe.set_mode_cpu()
model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
#model_def = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.prototxt'
#model_weights = 'G:/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel'
net = caffe.Net(model_def,
                model_weights,
                caffe.TEST)
net.blobs['data'].reshape(10,3,227,227)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))


# #pictureList = ['cat.jpg','cat2.jpg','fish-bike.jpg','cat gray.jpg','cat_gray.jpg']#,'fish-bike.jpg','cat gray.jpg','cat_gray.jpg'}
#
# pictureList = glob.glob(r"G:/256_ObjectCategories/*/*.jpg")
# #pictureList = glob.glob(r"G:/caffe/examples/images/*.jpg")
# #print pictureList
# #print pictureList
#
# featAll = []
#
# for pic in pictureList:
#     print pic
#     #image = caffe.io.load_image('G:/caffe/examples/images/'+pic)
#     image = caffe.io.load_image(pic)
#     transformed_image=transformer.preprocess('data',image)
#     net.blobs['data'].data[...] = transformed_image
#     output = net.forward()
#     feature = net.blobs['fc7'].data[0]
#     feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
#     tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
#     #tmpf = feature.reshape(1, feature.size)
#     #print tmpf
#     #tmpf = feature.reshape(1,feature.size)
#     s=tmpf.tolist()
#     fe=reduce(lambda x,y:x+y,s)
#     #print fe
#
# #    print(fe)
# #print len(fe)
# #print type(fe)
# #print(fe)
#     featAll.append(fe)
#
# reg = 0.0001
#
# X = featAll
# Y = np.zeros((np.shape(X)[0],30),float)
# count = 0
# for i in range(1,np.shape(X)[0]+1):
#     Y[i-1][count] = 1
#     if i % 60==0:
#         count = count + 1
#     if count == 2:
#         break
#
#
# np.savetxt('X.csv',X,delimiter=',')
# np.savetxt('Y.csv',Y,delimiter=',')

X = np.loadtxt('X.csv',double,delimiter='')
SampleMean = np.mean(X,axis=0)
X_ = X - SampleMean
covX = np.dot(np.transpose(X_),X_) / np.shape(X_)[0]
eigVec,eigVal = eigs(double(covX),128,'LM',)

# a = np.loadtxt('B.csv',int,delimiter=',')
# print a
# print np.shape(a)
#
# outputFile = open('outputFile.txt','w')
#
# for i in range(0,1800):
#     tempArr = a[i]
#     tempList = list(tempArr)
#     tempList = map(int,tempList)
#     tempList = map(str,tempList)
#     #print tempList
#     result = ''.join(tempList)
#     #print result
#
#     outputFile.write(result+"\n")
#
# outputFile.close()
#
#
# pc = np.loadtxt('Wx.csv',float,delimiter=',')
# np.savetxt('pc.txt',pc)
#
# R = np.loadtxt('R.csv',float,delimiter=',')
# np.savetxt('r.txt',R)
