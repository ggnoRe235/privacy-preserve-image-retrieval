import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
import glob
import os
import matplotlib.pyplot as plt
import caffe
import shutil
import random

def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance

def walk(path,nodeList):
    for root,dirs,files in os.walk(path):
        for dir in dirs:
            nodeList.append(os.path.join(root,dir) + '\\')

#
# plt.rcParams['figure.figsize']=(12,12)
# plt.rcParams['figure.dpi']=150
# plt.rcParams['image.interpolation']='nearest'
# plt.rcParams['image.cmap']='jet'
# caffe_root='G:/caffe/'
# model_root='G:/caffe/models/'
# caffe.set_mode_cpu()
# model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
# model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
# net = caffe.Net(model_def,
#                 model_weights,
#                 caffe.TEST)
# net.blobs['data'].reshape(10,3,227,227)
# transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
# transformer.set_transpose('data',(2,0,1))
# transformer.set_raw_scale('data',255)
# transformer.set_channel_swap('data',(2,1,0))
# Q_Path = 'G:/001_0001.jpg'
# image = caffe.io.load_image(Q_Path)
# transformed_image=transformer.preprocess('data',image)
# net.blobs['data'].data[...] = transformed_image
# output = net.forward()
# feature = net.blobs['fc7'].data[0]
# feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
# tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
# s=tmpf.tolist()
# fe=reduce(lambda x,y:x+y,s)
# fe = mat(fe)
# pc = np.loadtxt('pc.txt',float)
# R = np.loadtxt('r.txt',float)
# #temp = np.array(np.dot(np.dot(fe,pc),R))
# fe = np.array(np.dot(fe,pc))
# temp = np.array(np.dot(fe,R))
# temp[temp<0] = 0
# temp[temp>0] = 1
# Q = np.real(temp).astype(int)
#print Q
allPic = []
for dir in os.listdir('G:/test3/'):
    for pic in os.listdir('G:/test3/' + dir + '/'):
        allPic.append('G:/test3/' + dir + '/' + pic)

a = np.loadtxt('feature.csv',float,delimiter=',')
pc = np.loadtxt('Wx.csv',float,delimiter=',')
R = np.loadtxt('R.csv',float,delimiter=',')
sampleMean = np.loadtxt('mean.csv',float,delimiter=',')
a = a-sampleMean
a = np.dot(a,pc)
a = np.dot(a,R)
a[a>=0]=1
a[a<0]=0
count = 0
for Q_Path in allPic:
    Q = [a[count]]
    Q = np.array(Q)
    Q = Q.astype(int)
    #print Q
    insertStr = Q[0].astype(str)
    insertStr = (np.array(insertStr.tolist()).tostring() + '\n')
    root = ''

    path = 'G:\\pictures\\'
    files = os.listdir(path)
    for file in files:
        if os.path.isdir(path + file):
            root = path + file + '\\'
            break

    # print root
    # t = root.split('/')
    # print len(t)
    # print t[len(t)-2]

    nodeList = []
    NolList = []
    disList = []
    sumList = []
    tagList = []

    walk(root, nodeList)

    for name in nodeList:
        level = len(name.split('\\')) - 5
        while level + 1 > len(disList):
            disList.append([])
            # sumList.append(0)
            sumList.append(0)
            tagList.append(0)
    MinDis = 9999
    MinName = ''

    for name in nodeList:
        level = int(name.split('\\')[len(name.split('\\'))-2].split(',')[0])
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        arr = file.read().split('\n')[0]
        file.close()
        arr = map(''.join, zip(*[iter(arr)] * 1))
        arr = map(int, arr)
        dis = Distance(Q[0], arr)
        if dis < MinDis and level==0:
            MinName = name
            MinDis = dis
        disList[level].append(dis)

    for i in range(0, len(disList)):
        xList = argsort(disList[i])
        if len(disList[i])<=3:
            tagList[i] = disList[i][xList[len(disList[i])-1]]
        else:
            tagList[i] = disList[i][xList[2]]
        for num in disList[i]:
            sumList[i] = sumList[i] + num
        tagList[i] = 1 - (tagList[i] * 1.0 / sumList[i])
        # print disList[i]

    # print numList
    # print sumList

    for name in nodeList:
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        #level = len(name.split('\\')) - 5
        level = int(name.split('\\')[len(name.split('\\'))-2].split(',')[0])

        arr = file.read().split('\n')[0]
        file.close()
        arr = map(''.join, zip(*[iter(arr)] * 1))
        arr = map(int, arr)
        if (len(disList[level]) == 1):
            NolList.append(1)
        else:
            NolList.append(1 - ((Distance(Q[0], arr)) * 1.0 / sumList[level]))
        # print name
        # print Distance(Q[0],arr)


    def judge(leafList):
        for name in leafList:
            if name.split('\\')[len(name.split('\\')) - 2].split(',')[0] != '0':
                return False

        return True


    # nodeList = nodeList_

    leafList = [root]

    while (not judge(leafList)):
        for path in leafList:
            if path.split('\\')[len(path.split('\\')) - 2].split(',')[0] != '0':
                new = os.listdir(path)
                for i in range(0, len(new)):
                    if '.txt' in new[i]:
                        new.remove(new[i])
                        break
                for i in range(0, len(new)):
                    new[i] = path + new[i] + '\\'
                for name in new:
                    #level = len(name.split('\\')) - 5
                    level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
                    pos = nodeList.index(name)
                    if NolList[pos] >= tagList[level]:
                    #if NolList[pos] >= 0.8:
                        leafList.append(name)
                        #print leafList
                leafList.remove(path)

    #print leafList

    # print leafList
    picList = []
    disList = []

    if not MinName in leafList and MinName!='':
        leafList.append(MinName)
    #print MinName
    #print leafList
    for path in leafList:
        temp = os.listdir(path)
        temp.remove(path.split('\\')[len(path.split('\\')) - 2] + '.txt')
        for i in range(0, len(temp)):
            temp[i] = path + temp[i]
        picList = picList + temp

    for path in leafList:
        file = open('G:\\pictures\\' + path.split('\\')[len(path.split('\\')) - 2] + 'record.txt', 'r')
        strList = file.read().split('\n')
        for Str in strList:
            if Str != '':
                Str = map(''.join, zip(*[iter(Str)] * 1))
                Str = map(int, Str)
                disList.append(Distance(Q[0], Str))

    argList = np.argsort(disList)
    print picList[argList[0]]
    #print Q[0]
    TargetDir = (picList[argList[0]].split('\\'))
    TargetDir.pop()
    TargetDir = '\\'.join(TargetDir)
    TargetDir = TargetDir + '\\'
    recordName = 'G:\\pictures\\' + picList[argList[0]].split('\\')[len(picList[argList[0]].split('\\')) - 2] + 'record.txt'
    fileName = str(len(os.listdir(TargetDir))) + '.' + (Q_Path.split('/')[len((Q_Path).split('/')) - 1]).split('.')[1]
    shutil.copyfile(Q_Path, TargetDir + str(len(os.listdir(TargetDir))) + '.' +
                    (Q_Path.split('/')[len((Q_Path).split('/')) - 1]).split('.')[1])

    fileList = os.listdir(TargetDir)
    index = 0
    for i in range(0, len(fileList)):
        if '.txt' in fileList[i]:
            index = i
    fileList.pop(index)

    for i in range(0, len(fileList)):
        if fileName == fileList[i]:
            index = i

    #print insertStr
    #print index
    oldList = []
    newList = []
    file = open(recordName, 'r')
    for Str in file.read().split('\n'):
        if Str != '':
            oldList.append(Str)
    #print len(oldList)

    for i in range(0, len(oldList) + 1):
        #print i
        if i < index:
            newList.append(oldList[i])
        elif i == index:
            newList.append(insertStr)
        elif i > index:
            newList.append(oldList[i - 1])
    #print recordName
    outputFile = open(recordName, 'w')
    for i in range(0, len(newList)):
        outputFile.write(newList[i] + '\n')

    outputFile.close()

    # G:\\pictures\\5,0\\2,3\\1,3\\0,7\\
    # G:\\pictures\\5,0\\2,3\\1,3\\

    List = TargetDir.split('\\')
    List.pop()
    List.pop()
    DirName = '\\'.join(List)
    DirName = DirName + '\\'

    while (DirName != 'G:\\pictures\\'):
        fileName = DirName + DirName.split('\\')[len(DirName.split('\\')) - 2] + '.txt'
        print DirName.split('\\')[len(DirName.split('\\')) - 2]
        #print fileName
        file = open(fileName, 'r')
        content = file.read()
        E_Set = content.split('\n')[1]
        IND = content.split('\n')[2]
        file.close()

        arr = np.zeros(128)  # ,int)
        TList = []
        count_ = 0
        for Str in E_Set.split('|'):
            if Str != '':
                file = open('G:/pictures/' + Str + 'record.txt', 'r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    if rv != '':
                        TList.append(rv)
                        count_ = count_ + 1

        #NoList = random.sample(range(0, count), 40)
        # for no in NoList:
        #     rv = TList[no]
        #     tempList = map(''.join, zip(*[iter(rv)] * 1))
        #     tempList = map(int, tempList)
        #     arr = arr + tempList

        for rv in TList:
            tempList = map(''.join, zip(*[iter(rv)] * 1))
            tempList = map(int, tempList)
            arr = arr + tempList

        arr = arr / count_#40  # count
        arr[arr >= 0.63] = 1
        arr[arr < 0.63] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)
        file = open(fileName, 'w')
        file.write(np.array(arr.tolist()).tostring() + '\n')
        file.write(E_Set + '\n')
        file.write(IND)
        # NoList = random.sample(range(0, count), 40)
        List.pop()
        DirName = '\\'.join(List)
        DirName = DirName + '\\'

    count = count + 1
    if(count == 2):
        break