import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
import glob
import pickle
import os
import matplotlib.pyplot as plt
import caffe
from sklearn.decomposition import PCA

def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance

def walk(path,nodeList):
    for root,dirs,files in os.walk(path):
        for dir in dirs:
            nodeList.append(os.path.join(root,dir) + '\\')


plt.rcParams['figure.figsize']=(12,12)
plt.rcParams['figure.dpi']=150
plt.rcParams['image.interpolation']='nearest'
plt.rcParams['image.cmap']='jet'
caffe_root='G:/caffe/'
model_root='G:/caffe/models/'
Q_Path = 'G:/003_0004.jpg'
caffe.set_mode_cpu()
model_def = model_root + 'bvlc_reference_caffenet/deploy.prototxt'
model_weights = model_root + 'bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel'
net = caffe.Net(model_def,
                model_weights,
                caffe.TEST)
net.blobs['data'].reshape(10,3,227,227)
transformer = caffe.io.Transformer({'data':net.blobs['data'].data.shape})
transformer.set_transpose('data',(2,0,1))
transformer.set_raw_scale('data',255)
transformer.set_channel_swap('data',(2,1,0))
image = caffe.io.load_image(Q_Path)
transformed_image=transformer.preprocess('data',image)
net.blobs['data'].data[...] = transformed_image
output = net.forward()
feature = net.blobs['fc7'].data[0]
feature_standarlized = (feature - min(feature)) / (max(feature)-min(feature))
tmpf = feature_standarlized.reshape(1,feature_standarlized.size)
s=tmpf.tolist()
fe=reduce(lambda x,y:x+y,s)
fe = mat(fe)
#pca = pickle.load(open('E:/PyCharm/untitled/pc.txt','rb'))['pca_fit']
#fe = pca.transform(fe)
#pc = np.loadtxt('pc.txt',complex)
pc = np.loadtxt('pc.txt',float)
R = np.loadtxt('r.txt',float)
#temp = np.array(np.dot(np.dot(fe,pc),R))
fe = np.array(np.dot(fe,pc))
temp = np.array(np.dot(fe,R))
temp[temp<0] = 0
temp[temp>0] = 1
Q = np.real(temp).astype(int)
print Q

root = ''

path = 'G:\\pictures\\'
files = os.listdir(path)
for file in files:
    if os.path.isdir(path + file):
        root  = path + file + '\\'
        break

# print root
# t = root.split('/')
# print len(t)
# print t[len(t)-2]

nodeList = []
NolList = []
numList = []
sumList = []

maxLevel = int(root.split('\\')[len(root.split('\\'))-2].split(',')[0])

for i in range(0,maxLevel+1):
    numList.append(0)
    sumList.append(0)

walk(root,nodeList)

for name in nodeList:
    level = int(name.split('\\')[len(name.split('\\'))-2].split(',')[0])
    numList[level] = numList[level] + 1
    file = open(name+name.split('\\')[len(name.split('\\'))-2]+'.txt','r')
    arr = file.read().split('\n')[0]
    file.close()
    arr = map(''.join, zip(*[iter(arr)] * 1))
    arr = map(int, arr)
    sumList[level] = sumList[level] + Distance(Q[0],arr)

#print numList
#print sumList

for name in nodeList:
    file = open(name+name.split('\\')[len(name.split('\\'))-2]+'.txt','r')
    level = int(name.split('\\')[len(name.split('\\'))-2].split(',')[0])
    arr = file.read().split('\n')[0]
    file.close()
    arr = map(''.join, zip(*[iter(arr)] * 1))
    arr = map(int, arr)
    print name
    print Distance(Q[0],arr)
    NolList.append(1- (Distance(Q[0],arr) * 1.0/sumList[level]))

for i in range(0,len(nodeList)):
    name = nodeList[i]
    print name
    print NolList[i]
