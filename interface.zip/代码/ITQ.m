function [B,R] = ITQ(V, n_iter)

bit = size(V,2);
R = randn(bit,bit);
[U11 S2 V2] = svd(R);
R = U11(:,1:bit);

for iter=0:n_iter
    Z = V * R;      
    UX = ones(size(Z,1),size(Z,2)).*-1;
    UX(Z>=0) = 1;
    C = UX' * V;
    [UB,sigma,UA] = svd(C);    
    R = UA * UB';
end

B = UX;
B(B<0) = 0;









