import caffe
from caffe.proto import caffe_pb2
import lmdb
import os
import cv2
import numpy as np
import shutil
import glob
import matlab.engine
import time

#这个文件是用来提取用于生成索引树的图片的特征
#提取的过程中使用的是caffe框架自带的一个批量提取特征的工具extract_features.exe
#由于这个工具导出的特征是lmdb格式的，在程序的最后会将lmdb格式文件转换为csv格式
#调用工具的语句如下
#F:/caffe-windows/scripts/build/tools/Release/extract_features.exe F:/caffe-windows/examples/myExample_iter_431534.caffemodel F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt fc7 F:/temp '+num+' lmdb GPU 0
#F:/caffe-windows/scripts/build/tools/Release/extract_features.exe  这个是工具所在的路径
#F:/caffe-windows/examples/myExample_iter_431534.caffemodel  这个是用来导出全连接层的模型
#F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt  需要提供导出特征用的网络配置文件，因为我用的CNN网络就是CaffeNet，配置好caffe后在目录下面会直接给出使用caffeNet导出特征的网络配置文件，只需要改一些小的参数就可以用了，具体改法在word中给出了。
#fc7  fc7层就是CaffeNet里面的全连接层，如果要使用不同的网络的话这个层的名字也要对应变化
#F:/temp  这个路径是使用工具导出的lmdb文件的位置，在初次运行的时候需要手动先创建这个路径，因为程序运行的时候回先去删除它在创建新的
#num num就是要使用工具提取多少图片的图片特征
#lmdb就是导出的存储格式 GPU 0是代表使用哪一个GPU去进行特征提取


configFile = open('config.txt','r')
config = configFile.read()
configFile.close()
#读取配置文件

pictureList = glob.glob(config.split('\n')[3]+"*/*.jpg")
#这里就是读取前面存储在在文件夹中的生成索引树使用的图片列表

outputFile1 = open('F:/file_list.txt', 'w')
for pic in pictureList:
    outputFile1.write(pic + ' 0\n')
outputFile1.close()
#这里就是生成使用工具提取图片特征所需的文件，具体参见word文档中的imageNetVal.prototxt文件配置方法



shutil.rmtree('F:/temp')
#首先会删除原来已经有的存储lmdb文件的文件夹

num = str(int(config.split('\n')[1]) * 50)
command = 'F:/caffe-windows/scripts/build/tools/Release/extract_features.exe F:/caffe-windows/examples/myExample_iter_431534.caffemodel F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt fc7 F:/temp '+num+' lmdb GPU 0'
os.system(command)
#调用工具提取图片特征


lmdb_env = lmdb.open('F:/temp', readonly=True)
lmdb_txn = lmdb_env.begin()
lmdb_cursor = lmdb_txn.cursor()
datum = caffe_pb2.Datum()
imgeCnt=0
f2 = open('feature.csv','w')
for key, value in lmdb_cursor:
    datum.ParseFromString(value)
    label = datum.label
    data = caffe.io.datum_to_array(datum)
    DIM = datum.channels
    imgeCnt=imgeCnt+1
    if (imgeCnt%100==0):
        print("imgeCnt="+str(imgeCnt))
    for i in range(DIM-1):
       f2.write (str(data[i][0][0])+", ")
    f2.write (str(data[DIM-1][0][0])+"\n")

lmdb_env.close()
f2.close()
print (imgeCnt)

#这一段代码是用来将lmdb文件转换为csv文件，这个feature.csv文件里面就是全部的图片特征。





eng = matlab.engine.start_matlab()
time_start = time.time()
ret = eng.Process(int(config.split('\n')[0]))
time_end = time.time()
eng.quit()
print (ret)

#这里是启动matlab的引擎然后调用process.m文件进行特征的压缩和二值化。


a= np.loadtxt('B.csv',int,delimiter=',')
outputFile = open('outputFile1.txt','w')

for i in range(0,int(config.split('\n')[1]) * 50):
     tempArr = a[i]
     tempList = list(tempArr)
     tempList = map(int,tempList)
     tempList = map(str,tempList)
     #print tempList
     result = ''.join(tempList)
     #print result
     outputFile.write(result+"\n")
outputFile.close()

#调用完毕生成的二进制特征会存储在B.csv文件中，这里这一段代码吧CSV文件中的二进制串移动到了outputFile1.txt文件中，这里面就能看到一个完整的二进制串了