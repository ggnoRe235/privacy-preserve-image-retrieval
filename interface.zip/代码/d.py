from sklearn.cluster import KMeans
from sklearn.externals import joblib
from sklearn import cluster
import numpy as np
import shutil
import os
import glob
import random
import time


configFile = open('config.txt','r')
config = configFile.read()
configFile.close()


n_clusters = int(config.split('\n')[1])
nbits = int(config.split('\n')[0])
#这个地方的n_clusters就是使用图片的类数，因为这边caltech256数据集中每个类别的图片他都给分好了，默认使用的是一类图片生成一个叶子节点，如果要使用Kmeans方法来生成叶子节点，那这个n_clusters可以自己手动改一个。
#nbits是PCA_ITQ压缩后的特征长度


Tht = 0.42
Th = 0.5
#这是进行索引树生成时使用的两个参数


shutil.rmtree(config.split('\n')[5])
os.mkdir(config.split('\n')[5])

t1s = time.time()

for i in range(0,n_clusters):
    os.mkdir('G:/pictures/'+'0,'+str(i))
#默认使用的方法是一类图片一个叶子节点，因此这边就会首先在存储索引树的目录下生成存储叶子节点的路径
	


inputFile = open('E:/PyCharm/untitled/outputFile1.txt','r')
inputData = inputFile.read()
inputFile.close()
list = inputData.split('\n')
print len(list)

num = np.shape(list)[0]

arr = map(''.join , zip(*[iter(list[0])]*1))
arr = map(int, arr)

for i in range(1,num-1):
    Str = list[i]
    tempList = map(''.join , zip(*[iter(Str)]*1))
    tempList = map(int, tempList)
    arr = np.vstack((arr,tempList))

#这里是将之前导出的数据集特征向量在读取出来
	
#######################################################################################
CountOfFile = 0
CountOfDir = 0
SourceDir = config.split('\n')[3]
SourceDirEnd = os.listdir(SourceDir)
#print SourceDirEnd
for i in range(0,len(SourceDirEnd)):
    SourceDirEnd[i] = SourceDirEnd[i] + '/'
TargetDir = config.split('\n')[5]

TargetDirEnd = []
RecordName = []
RvFile = []
for i in range(0,n_clusters):
    TargetDirEnd.append('0,'+str(i)+'/')
    RecordName.append('0,'+str(i)+'.txt')
    RvFile.append(open(config.split('\n')[5]+'0,'+ str(i) + 'record.txt','a'))

picList = []

for dir in os.listdir(config.split('\n')[3]):
    for pic in os.listdir(config.split('\n')[3] + dir + '/'):
        picList.append(config.split('\n')[3] + dir + '/' + pic)

t1e = time.time()
count = 0
count_=0
for i in range(0,len(picList)):
    #print len(picList)
    #print picList[i]
    shutil.copy(picList[i],TargetDir + TargetDirEnd[count])
    count_ = count_ + 1
    if count_==50:
        count_=0
        count = count + 1
		
t2s = time.time()
		
count = 0
for i in range(0,n_clusters):
    for m in range(i*50,(i+1)*50):
        RvFile[i].write(list[m] + '\n')
    RvFile[i].close()
    new_RV = np.zeros(nbits)
    #for m in range(i*50,i*50+40):
    for m in range(i*50,i*50+50):
        new_RV = new_RV + arr[m]
    new_RV = new_RV / 50#40
    new_RV[new_RV>=Th] = 1
    new_RV[new_RV<Th] = 0
    new_RV = new_RV.astype(int)
    new_RV = new_RV.astype(str)

    OutputFile = open(TargetDir+TargetDirEnd[i]+RecordName[i],'a')
    OutputFile.write(np.array(new_RV.tolist()).tostring()+'\n')
    OutputFile.write('0,'+str(i)+'|'+'\n') #E set
    OutputFile.write('0')#+'\n') #IND
    OutputFile.close()
    OutputFile = open(config.split('\n')[5] + RecordName[i],'a')
    OutputFile.write(np.array(new_RV.tolist()).tostring())
    OutputFile.close()
#这一整段的代码都是用来生成叶子节点的，每一类图片对应一个叶子节点
##########################################################################	
	
##########################################################################
# CountOfFile = 0
# CountOfDir = 0
#
# SourceDir = config.split('\n')[3]
# SourceDirEnd = os.listdir(SourceDir)
# #print SourceDirEnd
# for i in range(0,len(SourceDirEnd)):
#     SourceDirEnd[i] = SourceDirEnd[i] + '/'
# TargetDir = config.split('\n')[5]
#
# TargetDirEnd = []
# RecordName = []
# RvFile = []
# for i in range(0,n_clusters):
#     TargetDirEnd.append('0,'+str(i)+'/')
#     RecordName.append('0,'+str(i)+'.txt')
#     RvFile.append(open(config.split('\n')[5]+'0,'+ str(i) + 'record.txt','a'))
#
# estimator = KMeans(n_clusters)
# res = estimator.fit_predict(arr)
# label_pred = estimator.labels_
# centroids = estimator.cluster_centers_
# inertia = estimator.inertia_
#
# dirList = os.listdir(config.split('\n')[3])
# for i in range(0,len(dirList)):
#     dirList[i]  = config.split('\n')[3] + dirList[i]
# fileList = []
# t = os.listdir(dirList[0])
# for i in range(0,len(t)):
#     fileList.append(t[i])
# for number in label_pred:
#     if CountOfFile == 50:
#         CountOfFile = 0
#         CountOfDir = CountOfDir + 1
#         fileList = []
#         t = os.listdir(dirList[CountOfDir])
#         for i in range(0, len(t)):
#             fileList.append(t[i])
#
#     FileName = fileList[CountOfFile]
#     CountOfFile = CountOfFile + 1
#     Source = SourceDir + SourceDirEnd[CountOfDir] + FileName
#     Target = TargetDir + TargetDirEnd[number] + FileName
#     shutil.copy(Source,Target)
#
# new_RV = np.zeros((n_clusters,nbits))
# cluster_num = np.zeros(n_clusters)
# nSamples = np.shape(label_pred)[0]
#
#
# for i in range(0,nSamples):
#     if(cluster_num[label_pred[i]]<50):
#         new_RV[label_pred[i]] = new_RV[label_pred[i]] + arr[i]
#         cluster_num[label_pred[i]] = cluster_num[label_pred[i]] + 1
#     file = RvFile[label_pred[i]]
#     tempstr = arr[i].astype(int)
#     tempstr = tempstr.astype(str)
#     file.write(np.array(tempstr.tolist()).tostring()+'\n')
#     #cluster_num[label_pred[i]] = cluster_num[label_pred[i]] + 1
#
# for i in range(0,n_clusters):
#     new_RV[i] = new_RV[i] / cluster_num[i]
#     #print cluster_num[i]
#
# for i in range(0,n_clusters):
#     RvFile[i].close()
#
# new_RV[new_RV>=Th] = 1
# new_RV[new_RV<Th] = 0
#
# new_RV = new_RV.astype(int)
# new_RV = new_RV.astype(str)
# #print new_RV
#
#
#
# for i in range(0,n_clusters):
#     OutputFile = open(TargetDir+TargetDirEnd[i]+RecordName[i],'a')
#     OutputFile.write(np.array(new_RV[i].tolist()).tostring()+'\n')
#     OutputFile.write('0,'+str(i)+'|'+'\n') #E set
#     OutputFile.write('0')#+'\n') #IND
#     OutputFile.close()
#     OutputFile = open('G:/pictures/' + RecordName[i],'a')
#     OutputFile.write(np.array(new_RV[i].tolist()).tostring())
#     OutputFile.close()

#这里被注释掉的代码是使用Kmeans进行叶子节点生成的方法，有需要可以使用。
#####################################################################


C_Set = []
for i in range(0,n_clusters):
    C_Set.append(TargetDir+TargetDirEnd[i])

#C_Set节点就是保存着当前可以操作的全部节点的集合，在完成叶子节点生成后首先将全部的叶子节点插入到这个集合中
	

def Distance(arr1,arr2):
    distance = 0
    for i in range(0,len(arr1)):
        if arr1[i]!=arr2[i]:
            distance = distance + 1
    return distance

#这个方法使用来计算垂直距离的方法
	

def FindNearest(C_Set):
#用于查找下一次进行合并的两个节点
    RecordMatrix = np.zeros((len(C_Set),len(C_Set)),int)
    for i in range(0,len(C_Set)):
        file1 = open(C_Set[i]+C_Set[i].split('/')[2]+'.txt','r')
        #print C_Set[i]+C_Set[i].split('/')[2]+'.txt'
        str1 = file1.read().split('\n')[0]
        arr1 = map(''.join, zip(*[iter(str1)] * 1))
        arr1 = map(int, arr1)
        file1.close()
        for m in range(0,len(C_Set)):
            file2 = open(C_Set[m]+C_Set[m].split('/')[2]+'.txt','r')
            str2 = file2.read().split('\n')[0]
            arr2 = map(''.join, zip(*[iter(str2)] * 1))
            arr2 = map(int, arr2)
            file2.close()
            distance = Distance(arr1,arr2)
            RecordMatrix[i][m] = distance
            Cu = C_Set[i]
            Cv = C_Set[m]
            file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVu = content.split('\n')[0]
            RVu = map(''.join, zip(*[iter(RVu)] * 1))
            RVu = map(int, RVu)
            INDu = int(content.split('\n')[2])
            Esetu = len(content.split('\n')[1].split('|'))
            file.close()
            file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
            content = file.read()
            RVv = content.split('\n')[0]
            RVv = map(''.join, zip(*[iter(RVv)] * 1))
            RVv = map(int, RVv)
            INDv = int(content.split('\n')[2])
            Esetv = len(content.split('\n')[1].split('|'))
            file.close()
            RecordMatrix[i][m] = distance
            max_value = max(INDu, INDv) * 1.0
            levelu = int(C_Set[i].split('/')[2].split(',')[0])
            levelv = int(C_Set[m].split('/')[2].split(',')[0])

###############################################################
            if Esetu>= 3**levelu + 1:     
                max_value = max(INDu, INDv) * 1.0
                if max_value == 0:
                    max_value = 1
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                if DM<Tht and levelu > levelv:
                    RecordMatrix[i][m] = 9999999
            if Esetv >= 3**levelv + 1:
                max_value = max(INDu, INDv) * 1.0
                if max_value == 0:
                    max_value = 1
                dis = Distance(RVu, RVv) * 1.0
                DM = (abs(dis - max_value)) / max_value
                if DM < Tht and levelu < levelv:
                    RecordMatrix[i][m] = 9999999

#这一段是第一部分改进，就是控制一个节点能包含的全部叶子节点数目
###############################################################


    Min = 99999999
    x = 0
    y = 0
    for i in range(0,len(C_Set)):
        for m in range(0,len(C_Set)):
            if i!=m and RecordMatrix[i][m]<Min:
                x = i
                y = m
                Min = RecordMatrix[i][m]
            elif i!=m and RecordMatrix[i][m]==Min:
            #     #print C_Set[i]
            #     #print C_Set[m]
            #
                level0 = int((C_Set[x].split('/')[2]).split(',')[0])
                level1 = int((C_Set[y].split('/')[2]).split(',')[0])
                level2 = int((C_Set[i].split('/')[2]).split(',')[0])
                level3 = int((C_Set[m].split('/')[2]).split(',')[0])
                max1 = max(level0,level1)
                min1 = min(level0,level1)
                max2 = max(level2,level3)
                min2 = min(level2,level3)
                if(max1 < max2):
                    x = i
                    y = m
                elif(max1 == max2 and min2 < min1):
                    x = i
                    y = m
                # else:
                #     x = m
                #     y = i
    #print RecordMatrix
    return x,y

LevelCount = [n_clusters]
#这个集合是用来记录某一个高度上目前有多少个节点，方便给新节点命名用的


def merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,flag):
    if flag == True:
        newLevel = max(levelu,levelv) + 1
        dirName = ''
        if newLevel > len(LevelCount)-1:
            LevelCount.append(1)
            dirName = str(newLevel)+','+str(LevelCount[newLevel]-1)
        elif newLevel <=len(LevelCount)-1:
            LevelCount[newLevel] = LevelCount[newLevel]+1
            dirName = str(newLevel) + ',' + str(LevelCount[newLevel] - 1)
        file = open(Cu+Cu.split('/')[2]+'.txt','r')
        E_Setu = file.read().split('\n')[1].split('|')
        file.close()
        file = open(Cv+Cv.split('/')[2]+'.txt','r')
        E_Setv = file.read().split('\n')[1].split('|')
        file.close()
        newE_Set = ''
        for Str in E_Setu:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        for Str in E_Setv:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        #newIND = max(INDu,INDv,Distance(RVu,RVv))

        disList = []
        for name1 in newE_Set.split('|'):
            for name2 in newE_Set.split('|'):
                if name1!=name2 and name1!='' and name2!='':
                    file1 = open(config.split('\n')[5]+name1+'record.txt','r')
                    file2 = open(config.split('\n')[5]+name2+'record.txt','r')
                    RV1 = file1.read().split('\n')[0]
                    RV2 = file2.read().split('\n')[1]
                    file1.close()
                    file2.close()
                    RV1 = map(''.join, zip(*[iter(RV1)] * 1))
                    RV1 = map(int, RV1)
                    RV2 = map(''.join, zip(*[iter(RV2)] * 1))
                    RV2 = map(int, RV2)
                    disList.append(Distance(RV1,RV2))
        newIND = max(disList)

        arr = np.zeros(nbits)#,int)
        TList = []
        count = 0
        for Str in newE_Set.split('|'):
            if Str!='':
                file = open(config.split('\n')[5] + Str + 'record.txt','r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    TList.append(rv)
                    count = count + 1
        #print count

        # NoList  = random.sample(range(0,count),50)
        # for no in NoList:
        #     rv = TList[no]
        #     tempList = map(''.join, zip(*[iter(rv)] * 1))
        #     tempList = map(int, tempList)
        #     arr = arr + tempList

        for rv in TList:
            tempList = map(''.join, zip(*[iter(rv)] * 1))
            tempList = map(int, tempList)
            arr = arr + tempList

        arr = arr / count#50
        arr[arr >= Th] = 1
        arr[arr < Th] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        os.mkdir(config.split('\n')[5]+dirName)
        shutil.move(Cu,config.split('\n')[5]+dirName)
        shutil.move(Cv,config.split('\n')[5]+dirName)
        C_Set.append(config.split('\n')[5]+dirName+'/')
        C_Set.remove(Cu)
        C_Set.remove(Cv)

        OutputFile = open(config.split('\n')[5]+dirName+'/'+dirName+'.txt', 'a')
        OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
        OutputFile.write(newE_Set+'\n')
        OutputFile.write(str(newIND))
        OutputFile.close()
        #print newIND



    else:
        newE_Set = ''
        #newIND = max(INDu,INDv,Distance(RVu,RVv))
        #newIND = Distance(RVu,RVv)
        file = open(Cu + Cu.split('/')[2] + '.txt', 'r')
        E_Setu = file.read().split('\n')[1].split('|')
        file.close()
        file = open(Cv + Cv.split('/')[2] + '.txt', 'r')
        E_Setv = file.read().split('\n')[1].split('|')
        file.close()
        for Str in E_Setu:
            if Str!= '':
                newE_Set = newE_Set + Str + '|'
        for Str in E_Setv:
            if Str!='':
                newE_Set = newE_Set + Str + '|'
        arr = np.zeros(nbits)#, int)
        count = 0

        disList = []
        for name1 in newE_Set.split('|'):
            for name2 in newE_Set.split('|'):
                if name1!=name2 and name1!='' and name2!='':
                    file1 = open(config.split('\n')[5]+name1+'record.txt','r')
                    file2 = open(config.split('\n')[5]+name2+'record.txt','r')
                    RV1 = file1.read().split('\n')[0]
                    RV2 = file2.read().split('\n')[1]
                    file1.close()
                    file2.close()
                    RV1 = map(''.join, zip(*[iter(RV1)] * 1))
                    RV1 = map(int, RV1)
                    RV2 = map(''.join, zip(*[iter(RV2)] * 1))
                    RV2 = map(int, RV2)
                    disList.append(Distance(RV1,RV2))
        newIND = max(disList)

        TList = []
        count = 0

        for Str in newE_Set.split('|'):
            if Str != '':
                file = open(config.split('\n')[5] + Str + 'record.txt', 'r')
                strList = file.read().split('\n')
                strList.pop()
                file.close()
                for rv in strList:
                    TList.append(rv)
                    count = count + 1

        # NoList = random.sample(range(0, count), 40)
        # for no in NoList:
        #     rv = TList[no]
        #     tempList = map(''.join, zip(*[iter(rv)] * 1))
        #     tempList = map(int, tempList)
        #     arr = arr + tempList

        for rv in TList:
            tempList = map(''.join, zip(*[iter(rv)] * 1))
            tempList = map(int, tempList)
            arr = arr + tempList

        #print count
        arr = arr / count#50
        arr[arr >= Th] = 1
        arr[arr < Th] = 0
        arr = arr.astype(int)
        arr = arr.astype(str)

        if levelu > levelv:
            OutputFile = open(Cu+Cu.split('/')[2]+'.txt','w+')
            OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
            OutputFile.write(newE_Set + '\n')
            OutputFile.write(str(newIND))
            OutputFile.close()
            C_Set.remove(Cv)
            shutil.move(Cv,Cu)

        elif levelu<levelv:
            OutputFile = open(Cv+Cv.split('/')[2]+'.txt','w+')
            OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
            OutputFile.write(newE_Set + '\n')
            OutputFile.write(str(newIND))
            OutputFile.close()
            C_Set.remove(Cu)
            shutil.move(Cu,Cv)
        elif levelu == levelv:
            idu = int((Cu.split('/')[2]).split(',')[1])
            idv = int((Cv.split('/')[2]).split(',')[1])
            if idu > idv:
                OutputFile = open(Cu + Cu.split('/')[2] + '.txt', 'w+')
                OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
                OutputFile.write(newE_Set + '\n')
                OutputFile.write(str(newIND))
                OutputFile.close()
                C_Set.remove(Cv)
                os.remove(Cv+Cv.split('/')[2]+'.txt')
                for files in os.listdir(Cv):
                    shutil.move(Cv + files, Cu)
                os.rmdir(Cv)
            else:
                OutputFile = open(Cv + Cv.split('/')[2] + '.txt', 'w+')
                OutputFile.write(np.array(arr.tolist()).tostring() + '\n')
                OutputFile.write(newE_Set + '\n')
                OutputFile.write(str(newIND))
                OutputFile.close()
                C_Set.remove(Cu)
                os.remove(Cu+Cu.split('/')[2]+'.txt')
                for files in os.listdir(Cu):
                    shutil.move(Cu + files, Cv)
                os.rmdir(Cu)
    return C_Set
#这个函数是用来进行节点合并的

LevelCount = [n_clusters]


while len(C_Set)>1:
#循环，每次都先调用FindNearest方法寻找下一次进行合并的两个节点，找到节点后根据借点情况和DM值大小决定采用的合并方法

    if len(C_Set) > 2:
        x,y = FindNearest(C_Set)
    else:
        x = 0
        y = 1
    Cu = C_Set[x]
    Cv = C_Set[y]
    file = open(Cu+Cu.split('/')[2]+'.txt','r')
    content = file.read()
    RVu = content.split('\n')[0]
    RVu = map(''.join, zip(*[iter(RVu)] * 1))
    RVu = map(int, RVu)
    levelu = int((Cu.split('/')[2]).split(',')[0])
    INDu = int(content.split('\n')[2])
    file.close()
    file = open(Cv+Cv.split('/')[2]+'.txt','r')
    content = file.read()
    RVv = content.split('\n')[0]
    RVv = map(''.join, zip(*[iter(RVv)] * 1))
    RVv = map(int, RVv)
    levelv = int((Cv.split('/')[2]).split(',')[0])
    INDv = int(content.split('\n')[2])
    file.close()
    if INDu==0 and INDv==0:
        C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
        print Cu + ' + ' + Cv + ' -> new'
    else:
        max_value = max(INDu,INDv) * 1.0
        dis = Distance(RVu,RVv) * 1.0
        #print type(max_value)
        #print type(dis)
        DM = (abs(dis - max_value))/max_value
        #print DM
        #print type(DM)
        if DM >= Tht or (levelu==levelv and levelu!=0):    #这里是第二个改进，就是限制不允许同一高度上的一个节点移入另一个节点中
            print Cu + ' + ' + Cv + ' -> new'
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,True)
            #C_Set = merge(C_Set, Cu, Cv, RVu, RVv, levelu, levelv, INDu, INDv, False)
        else:
            print Cu + ' -> ' + Cv
            C_Set = merge(C_Set,Cu,Cv,RVu,RVv,levelu,levelv,INDu,INDv,False)
    #print C_Set




t2e = time.time()

print t1e-t1s+t2e-t2s
