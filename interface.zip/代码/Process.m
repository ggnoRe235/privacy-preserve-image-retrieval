function ret = Process(n)
X = csvread('feature.csv');
sample_mean = mean(X,1);
X = bsxfun(@minus,X,sample_mean);
covX = X' * X /size(X,1);
OPTS.disp = 0;
[eigVec,~] = eigs(double(covX),n,'LM',OPTS);
X = X * eigVec;



[~,R] = ITQ(X,50);
B_ = X * R;
B_(B_>=0) = 1;
B_(B_<0) = 0;


dlmwrite('E:/PyCharm/untitled/R.csv',R,'newline','pc');
dlmwrite('E:/PyCharm/untitled/mean.csv',sample_mean,'newline','pc');
dlmwrite('E:/PyCharm/untitled/Wx.csv',eigVec,'newline','pc');
dlmwrite('E:/PyCharm/untitled/B.csv',B_,'newline','pc');
ret = 0;



