import numpy as np
from numpy import *
from scipy import sparse
from scipy.sparse.linalg import eigs
import scipy.sparse.linalg
import glob
import lmdb
import os
import time
import matplotlib.pyplot as plt
import caffe
from PIL import Image
from caffe.proto import caffe_pb2
import shutil


average = 1000 * 1000
def init(x,x0):
    chaos_seq = np.zeros(average)
    for i in range(average):
        x = key * x0 * (1 - x0)
        x0 = x
        chaos_seq[i] = x
    return chaos_seq

####################################################################
def decryption1(key, start=500, x0=0.1):
    for _ in range(start):
        x = key * x0 * (1 - x0)
        x0 = x
    return x, x0


def decryption2(imgpath,x,x0,count):
    img = Image.open(imgpath)
    #	img = img_en
    img_de = Image.new(mode=img.mode, size=img.size)
    width, height = img.size
    chaos_seq = np.zeros(width * height)
    if width*height > average:
        chaos_seq = np.zeros(width * height)
        for i in range(width * height):
            x = key * x0 * (1 - x0)
            x0 = x
            chaos_seq[i] = x
        idxs_de = np.argsort(chaos_seq)
    else:
        chaos_seq = init_chaos_seq[0:width*height]
        idxs_de = np.argsort(chaos_seq)
    i, j = 0, 0
    for idx in idxs_de:
        col = int(idx % width)
        row = int(idx // width)
        img_de.putpixel((col, row), img.getpixel((i, j)))
        i += 1
        if i >= width:
            j += 1
            i = 0
    img_de.save('G:/answer/' + str(count) + '.jpg')
#默认的保存解密图片的路径是在G:/answer有需要可以更改。
#这两个函数是用来进行图像解密的
####################################################################


def Distance2(EncRv1, EncRv2,nbits):
    return np.int(np.round((nbits - (np.dot(EncRv1.T, EncRv2))) / 2))
#这个函数用于计算加密序列间的垂直距离

def walk(path, nodeList):
    for root, dirs, files in os.walk(path):
        for dir in dirs:
            nodeList.append(os.path.join(root, dir) + '\\')


def generate():
    configFile = open('config.txt', 'r')
    config = configFile.read()
    configFile.close()
    pictureList = glob.glob(config.split('\n')[4] + "*/*.jpg")
    outputFile1 = open('F:/file_list.txt', 'w')
    for pic in pictureList:
        outputFile1.write(pic + ' 0\n')
    outputFile1.close()
    shutil.rmtree('F:/temp')
    num = str(int(config.split('\n')[1]) * 25)
    command = 'F:/caffe-windows/scripts/build/tools/Release/extract_features.exe F:/caffe-windows/examples/myExample_iter_431534.caffemodel F:/caffe-windows/examples/feature_extraction/imagenet_val2.prototxt fc7 F:/temp ' + num + ' lmdb GPU 0'
    os.system(command)
    lmdb_env = lmdb.open('F:/temp', readonly=True)
    lmdb_txn = lmdb_env.begin()
    lmdb_cursor = lmdb_txn.cursor()
    datum = caffe_pb2.Datum()
    imgeCnt = 0
    f2 = open('feature.csv', 'w')
    for key, value in lmdb_cursor:
        datum.ParseFromString(value)
        label = datum.label
        data = caffe.io.datum_to_array(datum)
        DIM = datum.channels
        imgeCnt = imgeCnt + 1
        if (imgeCnt % 100 == 0):
            print("imgeCnt=" + str(imgeCnt))
        for i in range(DIM - 1):
            f2.write(str(data[i][0][0]) + ", ")
        f2.write(str(data[DIM - 1][0][0]) + "\n")

    lmdb_env.close()
    f2.close()
    print (imgeCnt)
#这个generate首先是进行测试图片特征提取的，大致流程与ReadLMDBFile.py的方法相同。


configFile = open('config.txt', 'r')
config = configFile.read()
configFile.close()
nbits = int(config.split('\n')[0])
key = np.float(config.split('\n')[7])
x,x0 = decryption1(key)
init_chaos_seq = init(x,x0)



generate()
#调用generate完成测试集图片特征提取

nCount = 0
tCount = 0
#这两个是计数器，用来计算准确率的，nCount是不正确的数量，tCount是正确的数量
###############################################################
allPic = []
for dir in os.listdir(config.split('\n')[4]):
    for pic in os.listdir(config.split('\n')[4] + dir + '/'):
        allPic.append(config.split('\n')[4] + dir + '/' + pic)
#allPic文件是全部的测试集图片路径

sampleMean = np.loadtxt('mean.csv', float, delimiter=',')

a = np.loadtxt('feature.csv', float, delimiter=',')
pc = np.loadtxt('Wx.csv', float, delimiter=',')
R = np.loadtxt('R.csv', float, delimiter=',')
sampleMean = np.loadtxt('mean.csv', float, delimiter=',')
print np.shape(sampleMean)
print np.shape(a)
a = a - sampleMean
a = np.dot(a, pc)
a = np.dot(a, R)
a[a >= 0] = 1
a[a < 0] = 0
#这里是对提取出的图片特征进行压缩和而知还，转换为二进制串
##################################################################


count = 0
for Q_Path in allPic:#每次从测试集中取出一张图片
#####################################################################
    Q = [a[count]]
    S = np.loadtxt(config.split('\n')[5] + 'S.txt', int)
    M1 = np.loadtxt(config.split('\n')[5] + 'M1.txt', int)
    M2 = np.loadtxt(config.split('\n')[5] + 'M2.txt', int)
    RvArr2 = Q[0]
    RvArr21 = np.zeros(nbits).astype(int)
    RvArr22 = np.zeros(nbits).astype(int)
    for i in range(0, nbits):
        if S[i] == 0:
            RvArr21[i] = RvArr2[i]
            RvArr22[i] = RvArr2[i]
        else:
            if RvArr2[i] == 1:
                num1 = np.random.randint(100)
                num2 = num1 * (-1) + 1
                if (np.random.randint(2) == 0):
                    RvArr21[i] = num1
                    RvArr22[i] = num2
                else:
                    RvArr21[i] = num2
                    RvArr22[i] = num1
            elif RvArr2[i] == -1:
                num1 = np.random.randint(100)
                num2 = num1 * (-1) - 1
                if (np.random.randint(2) == 0):
                    RvArr21[i] = num1
                    RvArr22[i] = num2
                else:
                    RvArr21[i] = num2
                    RvArr22[i] = num1

    EncRv2 = np.hstack((np.dot(np.linalg.inv(M1), RvArr21), np.dot(np.linalg.inv(M2), RvArr22)))
#对这一张图片的二进制串特征进行加密生成加密序列
#########################################################################



    root = ''

    path = config.split('\n')[6]
    files = os.listdir(path)
    for file in files:
        if os.path.isdir(path + file):
            root = path + file + '\\'
            break


    nodeList = []
    NolList = []
    disList = []
    sumList = []
    tagList = []

    walk(root, nodeList)
#使用walk函数获取索引树中的全部节点
    for name in nodeList:
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
        while level + 1 > len(disList):
            disList.append([])
            sumList.append(0)
            tagList.append(0)
    MinDis = 9999
    MinName = ''
    for name in nodeList:
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        arr = file.read().split('\n')[0]
        file.close()
        arr = np.array(arr.split(','))
        arr = np.array(map(int, arr))
        dis = Distance2(arr, EncRv2,nbits)

        if dis < MinDis and level ==0:
            MinName = name
            MinDis = dis
        disList[level].append(dis)


    for i in range(0, len(disList)):
        xList = argsort(disList[i])
        if len(disList[i]) <= 3:
            tagList[i] = disList[i][xList[len(disList[i]) - 1]]
        else:
            tagList[i] = disList[i][xList[2]]
        for num in disList[i]:
            sumList[i] = sumList[i] + num
        tagList[i] = 1 - (tagList[i] * 1.0 / sumList[i])


    for name in nodeList:
        file = open(name + name.split('\\')[len(name.split('\\')) - 2] + '.txt', 'r')
        level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])

        arr = file.read().split('\n')[0]
        file.close()
        arr = np.array(arr.split(','))
        arr = np.array(map(int, arr))

        if (len(disList[level]) == 1):
            NolList.append(1)
        else:
            NolList.append(1 - (Distance2(arr, EncRv2,nbits) * 1.0 / sumList[level]))
#计算每一个节点各自对应的Nol值


    def judge(leafList):
        for name in leafList:
            if name.split('\\')[len(name.split('\\')) - 2].split(',')[0] != '0':
                return False

        return True
	#这个函数可以用来判断一个节点是不是叶子节点


###############################################
    leafList = [root]
    while (not judge(leafList)):
        for path in leafList:
            if path.split('\\')[len(path.split('\\')) - 2].split(',')[0] != '0':
                new = os.listdir(path)
                for i in range(0, len(new)):
                    if '.txt' in new[i]:
                        new.remove(new[i])
                        break
                for i in range(0, len(new)):
                    new[i] = path + new[i] + '\\'
                for name in new:
                    level = int(name.split('\\')[len(name.split('\\')) - 2].split(',')[0])
                    pos = nodeList.index(name)
                    if NolList[pos] >= tagList[level]:
					#直接将这里的tagList[level]换成一个固定的值就可以改为原来的未改进的系统了
                        leafList.append(name)
                leafList.remove(path)
#从根节点开始在索引树中进行检索，知道leafList列表中全都是叶子节点，就可以进行下一步一次比较每个叶子节点中
#图片与请求向量的垂直距离了
################################################


    picList = []
    disList = []


    if not (MinName in leafList) and MinName != '':
        leafList.append(MinName)
	print MinName

    for path in leafList:
        temp = os.listdir(path)
        temp.remove(path.split('\\')[len(path.split('\\')) - 2] + '.txt')
        for i in range(0, len(temp)):
            temp[i] = path + temp[i]
        picList = picList + temp


    for path in leafList:
        file = open(config.split('\n')[6] + path.split('\\')[len(path.split('\\')) - 2] + 'record.txt', 'r')
        strList = file.read().split('\n')
        for Str in strList:
            if Str != '':

                Str = np.array(Str.split(','))
                Str = np.array(map(int, Str))
                disList.append(Distance2(Str, EncRv2,nbits))


    argList = np.argsort(disList)
    print Q_Path
    if (len(argList) > 5):
        for i in range(0, 1):
            decryption2(picList[argList[i]],x,x0,count)
            name = picList[argList[i]].split('\\')[len(picList[argList[i]].split('\\')) - 1]
            print name
            if name.split('_')[0] != Q_Path.split('/')[3].split('_')[0]:
                nCount = nCount + 1
            else:
                tCount = tCount + 1
    print nCount
    print tCount
    print tCount * 1.0 / (nCount + tCount)
    count = count + 1

