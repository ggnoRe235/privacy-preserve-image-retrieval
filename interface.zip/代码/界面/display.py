import Tkinter as tk
import tkFileDialog
import os
import shutil
import glob
from PIL import Image,ImageTk

def search():
    shutil.rmtree('G:/file')
    newPic = tkFileDialog.askopenfilename(initialdir = 'G:/test2')
    os.mkdir('G:/file')
    shutil.copyfile(newPic,'G:/file/pic.jpg')
    os.system("python searchTest.py")

    tFile = open('G:/answer/0.txt', 'r')
    content = tFile.readline()
    tFile.close()


    IMAGES_PATH = 'G:/answer/'
    IMAGES_FORMAT = ['.jpg']

    image_names = [name for name in os.listdir(IMAGES_PATH) for item in IMAGES_FORMAT if
               os.path.splitext(name)[1] == item]

    to_image = Image.new('RGB', (3 * 200, 3 * 200))
    for y in range(1, 3 + 1):
        for x in range(1, 3 + 1):
            from_image = Image.open('G:/answer/' + image_names[3 * (y - 1) + x - 1]).resize((200, 200), Image.ANTIALIAS)
            to_image.paste(from_image, ((x - 1) * 200, (y - 1) * 200))

    #to_image.show()
    img = ImageTk.PhotoImage(to_image)
    l1.config(image=img)
    l1.image=img
    l2.config(text=content,wraplength = 500,justify='left')
    l2.text=content







def update():
    shutil.rmtree('G:/file2')
    newPic = tkFileDialog.askopenfilename(initialdir = 'G:/test2')
    os.mkdir('G:/file2')
    shutil.copyfile(newPic,'G:/file2/pic.jpg')
    os.system("python updateTest.py")

    tFile = open('G:/answer/0.txt', 'r')
    content = tFile.read()
    tFile.close()
    l2.config(text=content,wraplength = 500,justify='left')
    l2.text=content





root = tk.Tk()
root.title('display window')
root.geometry('1100x900')

btn = tk.Button(root,text='search')
btn.place(x=50,y=50,width=50,height=50)
btn.config(command=search)


btn2 = tk.Button(root,text='update')
btn2.place(x=50,y=150,width=50,height=50)
btn2.config(command=update)

l1=tk.Label(root)
l1.place(x=50,y=200,width=600,height=600)

l2 = tk.Label(root)
l2.place(x=150,y=50,width=600,height=100)


root.mainloop()


