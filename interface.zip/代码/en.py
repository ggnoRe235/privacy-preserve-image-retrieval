import numpy as np
import os
import shutil
import math
from PIL import Image
import glob
import time



def encryption1(key, start=500, x0=0.1):
    for _ in range(start):
        x = key * x0 * (1 - x0)
        x0 = x
    return x,x0
#Logistic的初始置乱，使系统达到充分混沌状态

###################################################
average = 1000 * 1000
def init(x,x0):
    chaos_seq = np.zeros(average)
    for i in range(average):
        x = key * x0 * (1 - x0)
        x0 = x
        chaos_seq[i] = x
    return chaos_seq
#这里为了加快图片加密的速度，先提前算了一个1000*1000长度的序列
####################################################

####################################################
def encryption2(imgpath,x,x0):
    tempList = imgpath.split('\\')
    name = tempList[len(tempList)-1]
    name = name.split('.')[0]
    name = name + '.bmp'
    name_ = ''
    for i in range(0,len(tempList)-1):
        name_ = name_ + tempList[i] + '\\'
    name = name_ + name

    img = Image.open(imgpath)
    img_en = Image.new(mode=img.mode, size=img.size)
    width, height = img.size
    #print width,height
    if width*height > average:
        chaos_seq = np.zeros(width * height)
        for i in range(width * height):
            x = key * x0 * (1 - x0)
            x0 = x
            chaos_seq[i] = x
        idxs_en = np.argsort(chaos_seq)
    else:
        chaos_seq = init_chaos_seq[0:width*height]
        idxs_en = np.argsort(chaos_seq)
	#首先按照图片的像素数计算序列的长度，生成一个对应长度的序列再进行置乱
    i, j = 0, 0
    #for x in range(0,width*height):
        #idx = idxs_en[x]
    for idx in idxs_en:
        col = int(idx % width)
        row = int(idx // width)
        img_en.putpixel((i, j), img.getpixel((col, row)))
        i += 1
        if i >= width:
            j += 1
            i = 0
    img_en.save(name)
    print name
#这一部分是对图片进行置乱加密的代码
####################################################


def walk(path, nodeList):
    for root, dirs, files in os.walk(path):
        for file in files:
            if '.txt' in file:
                nodeList.append(os.path.join(root, file))

#寻找索引树中的全部txt文件，每个txt文件中的二进制串向量都要进行加密
				
				
configFile = open('config.txt', 'r')
config = configFile.read()
configFile.close()
n = int(config.split('\n')[0])
key = np.float(config.split('\n')[7])






shutil.rmtree(config.split('\n')[6])
#首先会删除已经存在的保存加密索引树的路径

shutil.copytree(config.split('\n')[5], config.split('\n')[6])
#将未加密的索引树拷贝到新路径中

############################################
S = np.random.randint(0, 2, n)
M1 = np.random.randint(0, 2, (n, n))
M2 = np.random.randint(0, 2, (n, n))
np.savetxt(config.split('\n')[5] + 'S.txt', S)
np.savetxt(config.split('\n')[5] + 'M1.txt', M1)
np.savetxt(config.split('\n')[5] + 'M2.txt', M2)
#这一部分时进行密钥的选取，随机生成切分矩阵S，加密矩阵M1和加密矩阵M2
############################################

nodeList = []
walk(config.split('\n')[6], nodeList)
#NodeList中就是树中全部的节点

######################################################################
for name in nodeList:
    if not 'record' in name:
        file = open(name, 'r')
        content = file.read()
        RvCode1 = content.split('\n')[0]
        if len(content.split('\n')) == 1:
            E_set = ''
            IND = ''
        else:
            E_set = content.split('\n')[1]
            IND = content.split('\n')[2]
        file.close()
        RvArr1 = map(''.join, zip(*[iter(RvCode1)] * 1))
        RvArr1 = map(int, RvArr1)
        # RvArr1 = np.array(list(map(int,RvCode1))).astype(int)
        RvArr1[RvArr1 <= 0] = -1
        RvArr11 = np.zeros(n).astype(int)
        RvArr12 = np.zeros(n).astype(int)
        for i in range(0, n):
            if S[i] == 0:
                if RvArr1[i] == 1:
                    num1 = np.random.randint(100)
                    num2 = num1 * (-1) + 1
                    if (np.random.randint(2) == 0):
                        RvArr11[i] = num1
                        RvArr12[i] = num2
                    else:
                        RvArr11[i] = num2
                        RvArr12[i] = num1
                elif RvArr1[i] == -1:
                    num1 = np.random.randint(100)
                    num2 = num1 * (-1) - 1
                    if (np.random.randint(2) == 0):
                        RvArr11[i] = num1
                        RvArr12[i] = num2
                    else:
                        RvArr11[i] = num2
                        RvArr12[i] = num1
            else:
                RvArr11[i] = RvArr1[i]
                RvArr12[i] = RvArr1[i]

        # RvArr11 = RvArr11.astype(str)
        # RvArr12 = RvArr12.astype(str)

        # RvArr11 = np.vstack((RvArr11,RvArr12))
        EncRv1 = np.hstack((np.dot(M1.T, RvArr11), np.dot(M2.T, RvArr12)))
        EncRv1 = EncRv1.astype(str)
        line = ','.join(EncRv1)
        file = open(name, 'w')
        file.write(line)
        file.close()
        if E_set != '':
            outputFile = open(name, 'a+')
            outputFile.write('\n' + E_set + '\n')
            outputFile.write(IND)
            outputFile.close()


    else:
        newRv = ''
        file = open(name, 'r')
        strList = file.read().split('\n')
        file.close()
        file = open(name, 'w')
        file.write('')
        file.close()
        file = open(name, 'a+')
        for Str in strList:
            if Str != '':
                Str = map(''.join, zip(*[iter(Str)] * 1))
                RvArr1 = map(int, Str)
                RvArr1[RvArr1 <= 0] = -1
                RvArr11 = np.zeros(n).astype(int)
                RvArr12 = np.zeros(n).astype(int)
                for i in range(0, n):
                    if S[i] == 0:
                        if RvArr1[i] == 1:
                            num1 = np.random.randint(100)
                            num2 = num1 * (-1) + 1
                            if (np.random.randint(2) == 0):
                                RvArr11[i] = num1
                                RvArr12[i] = num2
                            else:
                                RvArr11[i] = num2
                                RvArr12[i] = num1
                        elif RvArr1[i] == -1:
                            num1 = np.random.randint(100)
                            num2 = num1 * (-1) - 1
                            if (np.random.randint(2) == 0):
                                RvArr11[i] = num1
                                RvArr12[i] = num2
                            else:
                                RvArr11[i] = num2
                                RvArr12[i] = num1
                    else:
                        RvArr11[i] = RvArr1[i]
                        RvArr12[i] = RvArr1[i]

                # RvArr11 = RvArr11.astype(str)
                # RvArr12 = RvArr12.astype(str)

                # RvArr11 = np.vstack((RvArr11, RvArr12))
                EncRv1 = np.hstack((np.dot(M1.T, RvArr11), np.dot(M2.T, RvArr12)))
                EncRv1 = EncRv1.astype(str)
                line = ','.join(EncRv1)
                file.write(line + '\n')

        #         if newRv=='':
        #             newRv = EncRv1
        #         else:
        #             newRv = np.vstack((newRv,EncRv1))
        # np.savetxt(name, newRv, delimiter=',')
        file.close()

#依次加密索引树中全部节点的RV向量和图片特征向量
######################################################################################

####################################################################
pictureList = []

g = os.walk(config.split('\n')[6])
for path,d,filelist in g:
    for filename in filelist:
        if filename.endswith('jpg'):
            pictureList.append(os.path.join(path, filename))

x,x0=encryption1(key)

init_chaos_seq = init(x,x0)
for impath in pictureList:
    encryption2(impath,x,x0)
    os.remove(impath)

#读取全部图片对每一张图片进行加密
#######################################################
