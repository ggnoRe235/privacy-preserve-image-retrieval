#import matlab.engine
import os
import random
import shutil

file = open('config.txt','r')
config = file.read()
nbits = int(config.split('\n')[0])
num = int(config.split('\n')[1])
Source = config.split('\n')[2]
Des1 = config.split('\n')[3]
Des2 = config.split('\n')[4]
file.close()
#这一部分是读配置文件


dirList = os.listdir(Source)
randomList  = random.sample(range(0,len(dirList)),num)

for name in os.listdir(Des1):
    shutil.rmtree(Des1 + name)
for name in os.listdir(Des2):
    shutil.rmtree(Des2 + name)

for i in range(0,len(randomList)):
    os.mkdir(Des1 + dirList[randomList[i]])
    os.mkdir(Des2 + dirList[randomList[i]])

#每一次都会先删除原来的文件夹再生成新的文件夹，第一次运行可能需要手动创建一个空目录

	
for i in range(0,len(randomList)):
    tempList = os.listdir(Source + dirList[randomList[i]])
    length = len(tempList)
    randomList2 = random.sample(range(0,length),75)
    for m in range(0,len(randomList2)):
        if(m>24):
            shutil.copy(Source + dirList[randomList[i]] + '/' + tempList[randomList2[m]],Des1 + dirList[randomList[i]] + '/' +tempList[randomList2[m]])
        else:
            shutil.copy(Source + dirList[randomList[i]] + '/' + tempList[randomList2[m]],Des2 + dirList[randomList[i]] + '/' +tempList[randomList2[m]])

#生成一个长度为75的不重复的随机数序列，这个序列的前24个值对应的图片用作测试，剩余的用作索引树生成